# -*- coding: utf-8 -*-
from linepy import *
from akad.ttypes import *
from multiprocessing import Pool, Process
from subprocess import check_output
from datetime import timedelta, date
from datetime import datetime
from time import sleep
from bs4 import BeautifulSoup
import time, random, pytz, atexit, ctypes, livejson, sys, shutil, json, codecs, ast, threading, glob, re, string, asyncio, os, traceback, requests, six, urllib, urllib.parse
#==================Login=================
loop = asyncio.get_event_loop()
cl = LINE('ericbots511@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
ka = LINE('ericbots512@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kb = LINE('ericbots510@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kc = LINE('ericbots5113@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kd = LINE('ericbots514@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
ke = LINE('ericbots525@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kf = LINE('ericbots517@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kg = LINE('ksamr50@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kh = LINE('ksamrtttt@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
ki = LINE('eriix71@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
kj = LINE('ksamr088@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
k1 = LINE('ksamr2001@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
k2 = LINE('ksamr077@gmail.com','Ssaa1122',appName='DESKTOPWIN\t5.20.2\tDESKTOP-1EJCDDQ\t10.0')
print ("\nSTARTING SYSTEM...")
#============[ thank for all friend // Line Protection ]=================#
linePoll = OEPoll(cl)
Bismillah=[cl,ka,kb,kc,kd,ke,kf,kg,kh,ki,kj]
Amin=[ka,kb,kc,kd,ke,kf,kg,kh,ki,kj]
mid = cl.getProfile().mid
Amid = ka.getProfile().mid
Bmid = kb.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = kd.getProfile().mid
Emid = ke.getProfile().mid
Fmid = ka.getProfile().mid
Gmid = kb.getProfile().mid
Hmid = kc.getProfile().mid
Imid = kd.getProfile().mid
Jmid = ke.getProfile().mid
Kmid = k1.getProfile().mid
Smid = k2.getProfile().mid
Bots=[mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Kmid,Smid]
Zie=["Mid"]
botlist=[cl,ka,kb,kc,kd,ke,kf,kg,kh,ki,kj,k1,k2]
Leakiller = Bots+Zie
msg_dict = {}
msg_dict1 = {}
Proemail = livejson.File('setting.json')
#for bottt in botlist:
#    for bott in Bots:
#        try:
#            bottt.findAndAddContactsByMid(bott)
#        except:
#            pass
wait = {
    "blacklist":{}
}
cctv = {
    "cyduk":{},
    "point":{},
    "sidermem":{}
}
mulai   = time.time()
tz = pytz.timezone("Asia/Jakarta")
timeNow = datetime.now(tz=tz)
def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d Hari %02d Jam %02d Menit %02d Detik' % (days, hours, mins, secs)
def likePost(self, mid, postId, likeType=1001):
    if mid is None:
        mid = cl.profile.mid
    if likeType not in [1001,1002,1003,1004,1005,1006]:
        raise Exception('Invalid parameter likeType')
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = cl.server.urlEncode(cl.server.LINE_TIMELINE_API, '/v23/like/create', params)
    data = {'likeType': likeType, 'postId': postId, 'actorId': mid}
    r = cl.server.postContent(url, data=data, headers=cl.server.channelHeaders)
    return r.json()
def createComment(self, mid, postId, text):
    if mid is None:
        mid = self.profile.mid
    params = {'homeId': mid, 'sourceType': 'TIMELINE'}
    url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/comment/create.json', params)
    data = {'commentText': text, 'activityExternalId': postId, 'actorId': mid}
    data = json.dumps(data)
    r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
    return r.json()
def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))
def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')
def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > timedelta(1):
            if "path" in msg_dict[data]:
                cl.deleteFile(msg_dict[data]["path"])
            del msg_dict[data]
def delete_log1():
    ndt = datetime.now()
    for data in msg_dict1:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict1[data]["createdTime"])) > timedelta(1):
            del msg_dict1[msg_id]
def atend():
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict, f, ensure_ascii=False, indent=4,separators=(',', ': '))
atexit.register(atend)
def atend1():
    with open("Log_data.json","w",encoding='utf8') as f:
        json.dump(msg_dict1, f, ensure_ascii=False, indent=4,separators=(',', ': '))
atexit.register(atend)
def restartProgram():
	print ('##----- PROGRAM RESTARTED -----##')
	python = sys.executable
	os.execl(python, python, *sys.argv)
def siderMembers(to, mid):
    try:
        arrData = ""
        textx = "「reader {} member」\nhai ka.. ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Proemail["siderMsg"]
            if no < len(mid):
                no += 1
                textx += "%i. " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def welcomeMembers(to, mid):
    try:
        arrData = ""
        textx = "「Member Join {}」\Wellcome ".format(str(len(mid)))
        arr = []
        no = 1
        num = 2
        for i in mid:
            ginfo = cl.getGroup(to)
            mention = "@x\n"
            slen = str(len(textx))
            elen = str(len(textx) + len(mention) - 1)
            arrData = {'S':slen, 'E':elen, 'M':i}
            arr.append(arrData)
            textx += mention+Proemail["sambutan"]+"\ndi group : "+str(ginfo.name)
            if no < len(mid):
                no += 1
                textx += "%i " % (num)
                num=(num+1)
            else:
                try:
                    no = "\n╚══[ {} ]".format(str(cl.getGroup(to).name))
                except:
                    no = "\n╚══[ Success ]"
        cl.sendMessage(to, textx, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))
def command(text):
    pesan = text.lower()
    if pesan.startswith(Proemail["keyCmd"]):
        cmd = pesan.replace(Proemail["keyCmd"],"")
    else:
        cmd = "command"
    return cmd
def help():
    key = Proemail["keyCmd"]
    key = key.title()
    helpMessage = "═══════☣ℒℯα☣═══════╗\n║「Help bots」\n╠═══════☣ℒℯα☣═══════╝\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Me\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Mid「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Info「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "kicker kick「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Kiss「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Bot kick「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Z1-5 kick「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Add con「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Mybot\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Status\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "About\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "/reboot\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Runtime\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Creator\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Sp\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + ".sp\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "tag\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "pro in\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "pro out\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "projs stay\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "projs join\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "projs bye\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Leave「Namagrup」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Ginfo\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "ourl\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "zourl\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "curl\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "zcurl\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "all grup\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "zall urlgrup\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Gruplist\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "listbot\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Infogrup「Zieka」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Infomem「Zieka」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Myrechat\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Rechat\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Lurk「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Lurkers\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Sider「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Mepict\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Uppict\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Pictgrup\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Bcg:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Setkey「New Key」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Mykey\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Resetkey\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "ID line:「Id Line nya」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Sholat:「Nama Kota」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Cuaca:「Nama Kota」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Lokasi:「Nama Kota」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Music:「Judul Lagu」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Lirik:「Judul Lagu」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Yt3:「Judul Lagu」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Yt4:「Judul Video」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Profileig:「Nama IG」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Cekdate:「tgl-bln-thn」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "max:「Zieka」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Spamtag「@」\n" + \
                  "║┝ℒℯα✍ ⚘ " + key + "Scall:「jumlahnya」\n" + \
                  "║┕ℒℯα✍ ⚘ " + key + "Scall \n" + \
                  "╠═══════☣ℒℯα☣═══════╗\n║「™Help bots™」\n╚═══════☣ℒℯα☣═══════╝"
    return helpMessage
def helpset():
    key = Proemail["keyCmd"]
    key = key.title()
    helpMessage1 = "╔═══════☣ℒℯα☣═══════╗\n║「Help bots」\n╠═══════☣ℒℯα☣═══════╝\n" + \
                  "║┍ℒℯα✍ ⚘" + key + "Protect「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Proqr「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Autokick「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Procancel「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Sticker「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Respon「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Contact「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Autojoin「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Autoadd「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Welcome「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Jticket「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Inta「on/off」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Bot:on\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Bot:off\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Bot:dell\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "delbot:off\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "addadmin「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "deladmin「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "addbot「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "delbot「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Refresh\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "mybot\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "adminlist\n" + \
                  "║┕ℒℯα✍ ⚘" + key + "botlist\n" + \
                  "╠═══════☣ℒℯα☣═══════╗\n║「line.me/ti/p/zie_rockstar」\n╚═══════☣ℒℯα☣═══════╝"
    return helpMessage1
def helpbot():
    key = Proemail["keyCmd"]
    key = key.title()
    helpMessage2 = "╔═══════☣ℒℯα☣═══════╗\n║「Help bots」\n╠═══════☣ℒℯα☣═══════╝\n" + \
                  "║┍ℒℯα✍ ⚘" + key + "Cban\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Ban:on\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Ban:off\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Unban:on\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Unban:off\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Ban「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Unban「@」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Banlist\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Refresh\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "cekmsg\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "sider:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "spam:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "add:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "tag:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "welcome:「Text」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "zname:「Nama」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "z1-10cn:「Nama」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Kickercn:「Nama」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Kickerpict「K fhoto」\n" + \
                  "║┝ℒℯα✍ ⚘" + key + "Gift:「Mid」「Jumlah」\n" + \
                  "║┕ℒℯα✍ ⚘" + key + "Spam:「Mid」「Jumlah」\n" + \
                  "╠═══════☣ℒℯα☣═══════╗\n║「line.me/ti/p/zie_rockstar」\n╚═══════☣ℒℯα☣═══════╝"
    return helpMessage2
def bot(op):
    global time
    global ast
    global groupParam
    try:
        if op.type == 11:
            if op.param2 in wait["blacklist"]:
               if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                   random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                   G = cl.getGroup(op.param1)
                   G.preventedJoinByTicket = True
                   cl.updateGroup(G)
               else:pass
        if op.type == 13:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    try:
                        ka.cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        try:
                            kb.cancelGroupInvitation(op.param1,[op.param3])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                            except:
                                try:
                                    kd.cancelGroupInvitation(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.cancelGroupInvitation(op.param1,[op.param3])
                                    except:
                                        try:
                                            kf.cancelGroupInvitation(op.param1,[op.param3])
                                        except:
                                            try:
                                                kg.cancelGroupInvitation(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kh.cancelGroupInvitation(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kj.cancelGroupInvitation(op.param1,[op.param3])
                                                        except:
                                                            pass
                else:pass
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    try:
                        ka.cancelGroupInvitation(op.param1,[op.param3])
                    except:
                        try:
                            kb.cancelGroupInvitation(op.param1,[op.param3])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                            except:
                                try:
                                    kd.cancelGroupInvitation(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.cancelGroupInvitation(op.param1,[op.param3])
                                    except:
                                        try:
                                            kf.cancelGroupInvitation(op.param1,[op.param3])
                                        except:
                                            try:
                                                kg.cancelGroupInvitation(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kh.cancelGroupInvitation(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kj.cancelGroupInvitation(op.param1,[op.param3])
                                                        except:
                                                            pass
                else:pass
            if op.param3 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    try:
                        ka.cancelGroupInvitation(op.param1,[op.param3])
                        ka.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kb.cancelGroupInvitation(op.param1,[op.param3])
                            kb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.cancelGroupInvitation(op.param1,[op.param3])
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kd.cancelGroupInvitation(op.param1,[op.param3])
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ke.cancelGroupInvitation(op.param1,[op.param3])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            kf.cancelGroupInvitation(op.param1,[op.param3])
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            try:
                                                kg.cancelGroupInvitation(op.param1,[op.param3])
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                            except:
                                                try:
                                                    kh.cancelGroupInvitation(op.param1,[op.param3])
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                except:
                                                    try:
                                                        ki.cancelGroupInvitation(op.param1,[op.param3])
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                    except:
                                                        try:
                                                            kj.cancelGroupInvitation(op.param1,[op.param3])
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                        except:
                                                            pass
                else:pass
        if op.type == 15:
            if op.param2 in Bots:
                try:
                    random.choice(Amin).inviteIntoGroup(op.param1,[Kmid,Smid])
                except:
                    try:
                        cl.inviteIntoGroup(op.param1,[Kmid,Smid])
                    except:
                        pass
        if op.type == 17:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            try:
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                            except:
                                                try:
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                except:
                                                    try:
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                    except:
                                                        try:
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                        except:
                                                            pass
                else:pass
        if op.type == 32:
            if op.param2 in wait["blacklist"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                    except:
                                        try:
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                        except:
                                            try:
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                            except:
                                                try:
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                except:
                                                    try:
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                    except:
                                                        try:
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                        except:
                                                            pass
                else:pass
        if op.type == 32:
            if op.param3 in Leakiller or op.param3 in Proemail["Bots"] or op.param3 in Proemail["admin"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.findAndAddContactsByMid(op.param3)
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kb.findAndAddContactsByMid(op.param3)
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.findAndAddContactsByMid(op.param3)
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kd.findAndAddContactsByMid(op.param3)
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.findAndAddContactsByMid(op.param3)
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kf.findAndAddContactsByMid(op.param3)
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                            kf.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kg.findAndAddContactsByMid(op.param3)
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                                kg.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kh.findAndAddContactsByMid(op.param3)
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ki.findAndAddContactsByMid(op.param3)
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kj.findAndAddContactsByMid(op.param3)
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                            kj.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                random.choice(Amin).findAndAddContactsByMid(op.param3)
                                                                random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                                random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                pass
                else:pass
        if op.type == 19:
            if mid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                        cl.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            cl.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                cl.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                    cl.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        cl.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kf.inviteIntoGroup(op.param1,[op.param3])
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                            cl.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kg.inviteIntoGroup(op.param1,[op.param3])
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                                cl.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                    cl.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        cl.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            kj.inviteIntoGroup(op.param1,[op.param3])
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                            cl.acceptGroupInvitation(op.param1)
                                                        except:
                                                            try:
                                                                random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                                random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                                cl.acceptGroupInvitation(op.param1)
                                                            except:
                                                                pass
                else:pass
                return
            if Amid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kb.inviteIntoGroup(op.param1,[op.param3])
                        kb.kickoutFromGroup(op.param1,[op.param2])
                        ka.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kc.inviteIntoGroup(op.param1,[op.param3])
                            kc.kickoutFromGroup(op.param1,[op.param2])
                            ka.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kd.inviteIntoGroup(op.param1,[op.param3])
                                kd.kickoutFromGroup(op.param1,[op.param2])
                                ka.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    ke.nviteIntoGroup(op.param1,[op.param3])
                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                    ke.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kf.inviteIntoGroup(op.param1,[op.param3])
                                        kf.kickoutFromGroup(op.param1,[op.param2])
                                        ka.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kg.inviteIntoGroup(op.param1,[op.param3])
                                            kg.kickoutFromGroup(op.param1,[op.param2])
                                            ka.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kh.inviteIntoGroup(op.param1,[op.param3])
                                                kh.kickoutFromGroup(op.param1,[op.param2])
                                                ka.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                    ka.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kj.inviteIntoGroup(op.param1,[op.param3])
                                                        kj.kickoutFromGroup(op.param1,[op.param2])
                                                        ka.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            ka.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Bmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kc.inviteIntoGroup(op.param1,[op.param3])
                        kc.kickoutFromGroup(op.param1,[op.param2])
                        kb.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kd.inviteIntoGroup(op.param1,[op.param3])
                            kd.kickoutFromGroup(op.param1,[op.param2])
                            kb.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ke.inviteIntoGroup(op.param1,[op.param3])
                                ke.kickoutFromGroup(op.param1,[op.param2])
                                kb.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kf.inviteIntoGroup(op.param1,[op.param3])
                                    kf.kickoutFromGroup(op.param1,[op.param2])
                                    kb.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kg.inviteIntoGroup(op.param1,[op.param3])
                                        kg.kickoutFromGroup(op.param1,[op.param2])
                                        kb.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kh.inviteIntoGroup(op.param1,[op.param3])
                                            kh.kickoutFromGroup(op.param1,[op.param2])
                                            kb.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                ki.inviteIntoGroup(op.param1,[op.param3])
                                                ki.kickoutFromGroup(op.param1,[op.param2])
                                                kb.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kj.inviteIntoGroup(op.param1,[op.param3])
                                                    kj.kickoutFromGroup(op.param1,[op.param2])
                                                    kb.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        ka.inviteIntoGroup(op.param1,[op.param3])
                                                        ka.kickoutFromGroup(op.param1,[op.param2])
                                                        kb.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kb.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Cmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kd.inviteIntoGroup(op.param1,[op.param3])
                        kd.kickoutFromGroup(op.param1,[op.param2])
                        kc.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ke.inviteIntoGroup(op.param1,[op.param3])
                            ke.kickoutFromGroup(op.param1,[op.param2])
                            kc.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kf.inviteIntoGroup(op.param1,[op.param3])
                                kf.kickoutFromGroup(op.param1,[op.param2])
                                kc.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kg.inviteIntoGroup(op.param1,[op.param3])
                                    kg.kickoutFromGroup(op.param1,[op.param2])
                                    kc.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kh.inviteIntoGroup(op.param1,[op.param3])
                                        kh.kickoutFromGroup(op.param1,[op.param2])
                                        kc.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                            kc.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kj.inviteIntoGroup(op.param1,[op.param3])
                                                kj.kickoutFromGroup(op.param1,[op.param2])
                                                kc.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                                    kc.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                                        kc.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kc.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Dmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ke.inviteIntoGroup(op.param1,[op.param3])
                        ke.kickoutFromGroup(op.param1,[op.param2])
                        kd.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kf.inviteIntoGroup(op.param1,[op.param3])
                            kf.kickoutFromGroup(op.param1,[op.param2])
                            kd.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kg.inviteIntoGroup(op.param1,[op.param3])
                                kg.kickoutFromGroup(op.param1,[op.param2])
                                kd.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                    kd.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                        kd.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kj.inviteIntoGroup(op.param1,[op.param3])
                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                            kd.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                ka.inviteIntoGroup(op.param1,[op.param3])
                                                ka.kickoutFromGroup(op.param1,[op.param2])
                                                kd.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                                    kd.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                                        kd.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kd.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Emid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kf.inviteIntoGroup(op.param1,[op.param3])
                        kf.kickoutFromGroup(op.param1,[op.param2])
                        ke.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kg.inviteIntoGroup(op.param1,[op.param3])
                            kg.kickoutFromGroup(op.param1,[op.param2])
                            ke.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kh.inviteIntoGroup(op.param1,[op.param3])
                                kh.kickoutFromGroup(op.param1,[op.param2])
                                ke.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                    ke.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kj.inviteIntoGroup(op.param1,[op.param3])
                                        kj.kickoutFromGroup(op.param1,[op.param2])
                                        ke.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ka.inviteIntoGroup(op.param1,[op.param3])
                                            ka.kickoutFromGroup(op.param1,[op.param2])
                                            ke.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kb.inviteIntoGroup(op.param1,[op.param3])
                                                kb.kickoutFromGroup(op.param1,[op.param2])
                                                ke.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                                        ke.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            ke.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Fmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kg.inviteIntoGroup(op.param1,[op.param3])
                        kg.kickoutFromGroup(op.param1,[op.param2])
                        kf.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kh.inviteIntoGroup(op.param1,[op.param3])
                            kh.kickoutFromGroup(op.param1,[op.param2])
                            kf.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ki.inviteIntoGroup(op.param1,[op.param3])
                                ki.kickoutFromGroup(op.param1,[op.param2])
                                kf.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kj.inviteIntoGroup(op.param1,[op.param3])
                                    kj.kickoutFromGroup(op.param1,[op.param2])
                                    kf.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        ka.inviteIntoGroup(op.param1,[op.param3])
                                        ka.kickoutFromGroup(op.param1,[op.param2])
                                        kf.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kb.inviteIntoGroup(op.param1,[op.param3])
                                            kb.kickoutFromGroup(op.param1,[op.param2])
                                            kf.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kc.inviteIntoGroup(op.param1,[op.param3])
                                                kc.kickoutFromGroup(op.param1,[op.param2])
                                                kf.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                                    kf.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                                        kf.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kf.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Gmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kh.inviteIntoGroup(op.param1,[op.param3])
                        kh.kickoutFromGroup(op.param1,[op.param2])
                        kg.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ki.inviteIntoGroup(op.param1,[op.param3])
                            ki.kickoutFromGroup(op.param1,[op.param2])
                            kg.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kj.inviteIntoGroup(op.param1,[op.param3])
                                kj.kickoutFromGroup(op.param1,[op.param2])
                                kg.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    kg.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kg.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kg.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kg.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    kg.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kf.inviteIntoGroup(op.param1,[op.param3])
                                                        kf.kickoutFromGroup(op.param1,[op.param2])
                                                        kg.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kg.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Hmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ki.inviteIntoGroup(op.param1,[op.param3])
                        ki.kickoutFromGroup(op.param1,[op.param2])
                        kh.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kj.inviteIntoGroup(op.param1,[op.param3])
                            kj.kickoutFromGroup(op.param1,[op.param2])
                            kh.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                ka.inviteIntoGroup(op.param1,[op.param3])
                                ka.kickoutFromGroup(op.param1,[op.param2])
                                kh.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kb.inviteIntoGroup(op.param1,[op.param3])
                                    kb.kickoutFromGroup(op.param1,[op.param2])
                                    kh.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kc.inviteIntoGroup(op.param1,[op.param3])
                                        kc.kickoutFromGroup(op.param1,[op.param2])
                                        kh.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kd.inviteIntoGroup(op.param1,[op.param3])
                                            kd.kickoutFromGroup(op.param1,[op.param2])
                                            kh.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                ke.inviteIntoGroup(op.param1,[op.param3])
                                                ke.kickoutFromGroup(op.param1,[op.param2])
                                                kh.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kf.inviteIntoGroup(op.param1,[op.param3])
                                                    kf.kickoutFromGroup(op.param1,[op.param2])
                                                    kh.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kg.inviteIntoGroup(op.param1,[op.param3])
                                                        kg.kickoutFromGroup(op.param1,[op.param2])
                                                        kh.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kh.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Imid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        kj.inviteIntoGroup(op.param1,[op.param3])
                        kj.kickoutFromGroup(op.param1,[op.param2])
                        ki.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            ka.inviteIntoGroup(op.param1,[op.param3])
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ki.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kb.inviteIntoGroup(op.param1,[op.param3])
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                ki.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    ki.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        ki.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ki.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kf.inviteIntoGroup(op.param1,[op.param3])
                                                kf.kickoutFromGroup(op.param1,[op.param2])
                                                ki.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kg.inviteIntoGroup(op.param1,[op.param3])
                                                    kg.kickoutFromGroup(op.param1,[op.param2])
                                                    ki.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        kh.inviteIntoGroup(op.param1,[op.param3])
                                                        kh.kickoutFromGroup(op.param1,[op.param2])
                                                        ki.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            ki.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Jmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.inviteIntoGroup(op.param1,[op.param3])
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        kj.acceptGroupInvitation(op.param1)
                    except:
                        try:
                            kb.inviteIntoGroup(op.param1,[op.param3])
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kj.acceptGroupInvitation(op.param1)
                        except:
                            try:
                                kc.inviteIntoGroup(op.param1,[op.param3])
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kj.acceptGroupInvitation(op.param1)
                            except:
                                try:
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kj.acceptGroupInvitation(op.param1)
                                except:
                                    try:
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        kj.acceptGroupInvitation(op.param1)
                                    except:
                                        try:
                                            kf.inviteIntoGroup(op.param1,[op.param3])
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                            kj.acceptGroupInvitation(op.param1)
                                        except:
                                            try:
                                                kg.inviteIntoGroup(op.param1,[op.param3])
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                                kj.acceptGroupInvitation(op.param1)
                                            except:
                                                try:
                                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                    kj.acceptGroupInvitation(op.param1)
                                                except:
                                                    try:
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        kj.acceptGroupInvitation(op.param1)
                                                    except:
                                                        try:
                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                            kj.acceptGroupInvitation(op.param1)
                                                        except:
                                                            pass
                else:pass
                return
            if Kmid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                            kf.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                                kg.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                            kj.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            pass
                else:pass
                return
            if Smid in op.param3:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    wait["blacklist"][op.param2] = True
                    try:
                        ka.kickoutFromGroup(op.param1,[op.param2])
                        ka.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            kb.kickoutFromGroup(op.param1,[op.param2])
                            kb.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kc.kickoutFromGroup(op.param1,[op.param2])
                                kc.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kd.kickoutFromGroup(op.param1,[op.param2])
                                    kd.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        ke.kickoutFromGroup(op.param1,[op.param2])
                                        ke.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kf.kickoutFromGroup(op.param1,[op.param2])
                                            kf.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kg.kickoutFromGroup(op.param1,[op.param2])
                                                kg.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kh.kickoutFromGroup(op.param1,[op.param2])
                                                    kh.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        ki.kickoutFromGroup(op.param1,[op.param2])
                                                        ki.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kj.kickoutFromGroup(op.param1,[op.param2])
                                                            kj.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            pass
                else:pass
                return
            if op.type == 19:
                if op.param3 in Bots:
                    if op.param2 not in Leakiller:
                        wait["blacklist"][op.param2] = True
                        try:
                            ka.findAndAddContactsByMid(op.param3)
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kf.findAndAddContactsByMid(op.param3)
                                                kf.kickoutFromGroup(op.param1,[op.param2])
                                                kf.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kg.findAndAddContactsByMid(op.param3)
                                                    kg.kickoutFromGroup(op.param1,[op.param2])
                                                    kg.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kh.findAndAddContactsByMid(op.param3)
                                                        kh.kickoutFromGroup(op.param1,[op.param2])
                                                        kh.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            ki.findAndAddContactsByMid(op.param3)
                                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kj.findAndAddContactsByMid(op.param3)
                                                                kj.kickoutFromGroup(op.param1,[op.param2])
                                                                kj.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                pass
                    else:pass
                    return
                if op.param3 in Zie:
                    if op.param2 not in Leakiller:
                        wait["blacklist"][op.param2] = True
                        try:
                            k1.acceptGroupInvitation(op.param1)
                            x = k1.getGroup(op.param1)
                            x.preventedJoinByTicket = False
                            k1.updateGroup(x)
                            Ti= k1.reissueGroupTicket(op.param1)
                            time.sleep(0.001)
                            cl.acceptGroupInvitationByTicket(op.param1,Ti)
                            ka.acceptGroupInvitationByTicket(op.param1,Ti)
                            kb.acceptGroupInvitationByTicket(op.param1,Ti)
                            kc.acceptGroupInvitationByTicket(op.param1,Ti)
                            kd.acceptGroupInvitationByTicket(op.param1,Ti)
                            ke.acceptGroupInvitationByTicket(op.param1,Ti)
                            kf.acceptGroupInvitationByTicket(op.param1,Ti)
                            kg.acceptGroupInvitationByTicket(op.param1,Ti)
                            kh.acceptGroupInvitationByTicket(op.param1,Ti)
                            ki.acceptGroupInvitationByTicket(op.param1,Ti)
                            kj.acceptGroupInvitationByTicket(op.param1,Ti)
                            k1.kickoutFromGroup(op.param1,[op.param2])
                            k1.leaveGroup(op.param1)
                            x = cl.getGroup(op.param1)
                            x.preventedJoinByTicket = True
                            cl.updateGroup(x)
                        except:
                            try:
                                k2.acceptGroupInvitation(op.param1)
                                k2.inviteIntoGroup(op.param1,[mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid])
                                k2.kickoutFromGroup(op.param1,[op.param2])
                                cl.acceptGroupInvitation(op.param1)
                                ka.acceptGroupInvitation(op.param1)
                                kb.acceptGroupInvitation(op.param1)
                                kc.acceptGroupInvitation(op.param1)
                                kd.acceptGroupInvitation(op.param1)
                                ke.acceptGroupInvitation(op.param1)
                                kf.acceptGroupInvitation(op.param1)
                                kg.acceptGroupInvitation(op.param1)
                                kh.acceptGroupInvitation(op.param1)
                                ki.acceptGroupInvitation(op.param1)
                                kj.acceptGroupInvitation(op.param1)
                                k2.leaveGroup(op.param1)
                                x = ka.getGroup(op.param1)
                                x.preventedJoinByTicket = True
                                ka.updateGroup(x)
                            except:
                                try:
                                    ka.findAndAddContactsByMid(op.param3)
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kd.findAndAddContactsByMid(op.param3)
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(op.param3)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kf.findAndAddContactsByMid(op.param3)
                                                        kf.kickoutFromGroup(op.param1,[op.param2])
                                                        kf.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kg.findAndAddContactsByMid(op.param3)
                                                            kg.kickoutFromGroup(op.param1,[op.param2])
                                                            kg.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kh.findAndAddContactsByMid(op.param3)
                                                                kh.kickoutFromGroup(op.param1,[op.param2])
                                                                kh.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                try:
                                                                    ki.findAndAddContactsByMid(op.param3)
                                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                                except:
                                                                    try:
                                                                        kj.findAndAddContactsByMid(op.param3)
                                                                        kj.kickoutFromGroup(op.param1,[op.param2])
                                                                        kj.inviteIntoGroup(op.param1,[op.param3])
                                                                    except:
                                                                        pass
                    else:pass
                    return
                if op.param3 in Proemail["Bots"]:
                    if op.param2 not in Leakiller or op.param2 not in Proemail["Bots"] or op.param2 not in Proemail["admin"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            ka.findAndAddContactsByMid(op.param3)
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kf.findAndAddContactsByMid(op.param3)
                                                kf.kickoutFromGroup(op.param1,[op.param2])
                                                kf.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kg.findAndAddContactsByMid(op.param3)
                                                    kg.kickoutFromGroup(op.param1,[op.param2])
                                                    kg.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kh.findAndAddContactsByMid(op.param3)
                                                        kh.kickoutFromGroup(op.param1,[op.param2])
                                                        kh.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            ki.findAndAddContactsByMid(op.param3)
                                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kj.findAndAddContactsByMid(op.param3)
                                                                kj.kickoutFromGroup(op.param1,[op.param2])
                                                                kj.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                pass
                    else:pass
                    return
                if op.param3 in Proemail["admin"]:
                    if op.param2 not in Leakiller or op.param2 not in Proemail["Bots"] or op.param2 not in Proemail["admin"]:
                        wait["blacklist"][op.param2] = True
                        try:
                            ka.findAndAddContactsByMid(op.param3)
                            ka.kickoutFromGroup(op.param1,[op.param2])
                            ka.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                kb.findAndAddContactsByMid(op.param3)
                                kb.kickoutFromGroup(op.param1,[op.param2])
                                kb.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                try:
                                    kc.findAndAddContactsByMid(op.param3)
                                    kc.kickoutFromGroup(op.param1,[op.param2])
                                    kc.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kd.findAndAddContactsByMid(op.param3)
                                        kd.kickoutFromGroup(op.param1,[op.param2])
                                        kd.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            ke.findAndAddContactsByMid(op.param3)
                                            ke.kickoutFromGroup(op.param1,[op.param2])
                                            ke.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kf.findAndAddContactsByMid(op.param3)
                                                kf.kickoutFromGroup(op.param1,[op.param2])
                                                kf.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    kg.findAndAddContactsByMid(op.param3)
                                                    kg.kickoutFromGroup(op.param1,[op.param2])
                                                    kg.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kh.findAndAddContactsByMid(op.param3)
                                                        kh.kickoutFromGroup(op.param1,[op.param2])
                                                        kh.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            ki.findAndAddContactsByMid(op.param3)
                                                            ki.kickoutFromGroup(op.param1,[op.param2])
                                                            ki.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kj.findAndAddContactsByMid(op.param3)
                                                                kj.kickoutFromGroup(op.param1,[op.param2])
                                                                kj.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                pass
                    else:pass
                    return
        if op.type == 0:
            return
        if op.type == 5:
            if Proemail["autoAdd"] == True:
                if op.param2 not in Leakiller:
                    cl.findAndAddContactsByMid(op.param1)
                    if (Proemail["message"] in [" "," ","\n",None]):
                        pass
                    else:
                        cl.sendMessage(op.param1, Proemail["message"])
        if op.type == 11:
            if op.param1 in Proemail["proqr"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    if cl.getGroup(op.param1).preventedJoinByTicket == False:
                        wait["blacklist"][op.param2] = True
                        random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                        Z = random.choice(Bismillah).getGroup(op.param1)
                        Z.preventedJoinByTicket = True
                        random.choice(Bismillah).updateGroup(Z)
                else:
                    pass
        if op.type == 11:
            if op.param1 in Proemail["intaPoint"]:
                if op.param2 in Leakiller and op.param2 in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                    pass
                else:
                    X = cl.getGroup(op.param1)
                    if X.preventedJoinByTicket == True:
                        pass
                    else:
                        cl.updateGroup(X)
                        invsend = 0
                        Ti = cl.reissueGroupTicket(op.param1)
                        ka.acceptGroupInvitationByTicket(op.param1,Ti)
                        kb.acceptGroupInvitationByTicket(op.param1,Ti)
                        kc.acceptGroupInvitationByTicket(op.param1,Ti)
                        kd.acceptGroupInvitationByTicket(op.param1,Ti)
                        ke.acceptGroupInvitationByTicket(op.param1,Ti)
                        kf.acceptGroupInvitationByTicket(op.param1,Ti)
                        kg.acceptGroupInvitationByTicket(op.param1,Ti)
                        kh.acceptGroupInvitationByTicket(op.param1,Ti)
                        ki.acceptGroupInvitationByTicket(op.param1,Ti)
                        kj.acceptGroupInvitationByTicket(op.param1,Ti)
        if op.type == 13:
            if mid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        cl.acceptGroupInvitation(op.param1)
                        cl.leaveGroup(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
            if Amid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        ka.acceptGroupInvitation(op.param1)
                        ka.leaveGroup(op.param1)
                    else:
                        ka.acceptGroupInvitation(op.param1)
            if Bmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kb.acceptGroupInvitation(op.param1)
                        kb.leaveGroup(op.param1)
                    else:
                        kb.acceptGroupInvitation(op.param1)
            if Cmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kc.acceptGroupInvitation(op.param1)
                        kc.leaveGroup(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
            if Dmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kd.acceptGroupInvitation(op.param1)
                        kd.leaveGroup(op.param1)
                    else:
                        kd.acceptGroupInvitation(op.param1)
            if Emid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        ke.acceptGroupInvitation(op.param1)
                        ke.leaveGroup(op.param1)
                    else:
                        ke.acceptGroupInvitation(op.param1)
            if Fmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kf.acceptGroupInvitation(op.param1)
                        kf.leaveGroup(op.param1)
                    else:
                        kf.acceptGroupInvitation(op.param1)
            if Gmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kg.acceptGroupInvitation(op.param1)
                        kg.leaveGroup(op.param1)
                    else:
                        kg.acceptGroupInvitation(op.param1)
            if Hmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kh.acceptGroupInvitation(op.param1)
                        kh.leaveGroup(op.param1)
                    else:
                        kh.acceptGroupInvitation(op.param1)
            if Imid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        ki.acceptGroupInvitation(op.param1)
                        ki.leaveGroup(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
            if Jmid in op.param3:
                if Proemail["autoJoin"] == True:
                    if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                        kj.acceptGroupInvitation(op.param1)
                        kj.leaveGroup(op.param1)
                    else:
                        kj.acceptGroupInvitation(op.param1)
        if op.type == 13:
            if op.param1 in Proemail["proInvite"]:
                if op.param2 in Leakiller or op.param2 in Proemail["Bots"] or op.param2 in Proemail["admin"]:
                    pass
                else:
                    try:
                        if op.param3 in Leakiller or op.param3 in Proemail["Bots"] or op.param3 in Proemail["admin"]:
                            pass
                        else:
                           if op.param2 not in Leakiller or op.param2 not in Proemail["Bots"] or op.param2 not in Proemail["admin"]:
                                wait["blacklist"][op.param2] = True
                                anu = cl.getCompactGroup(op.param1)
                                if anu.invitee is not None:
                                    pipo = [a.mid for a in anu.invitee]
                                    for target in pipo:
                                        if target in op.param3 and target not in Leakiller and target not in Proemail["Bots"] and target not in Proemail["admin"]:
                                            wait["blacklist"][target] = True
                                            random.choice(Amin).cancelGroupInvitation(op.param1,[target])
                                    random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                           else:pass
                    except:
                        pass
        if op.type == 15:
            if op.param1 in Proemail["leaveMsg"]:
                if op.param2 not in Leakiller and op.param2 not in Proemail["admin"] and op.param2 not in Proemail["Bots"]:
                    return
                else:
                    cl.sendMessage(op.param1, Proemail["leftmsg"])
        if op.type == 17:
            if op.param1 in Proemail["welcome"]:
                if op.param2 in Leakiller or op.param2 in Proemail["Bots"] or op.param2 in Proemail["admin"]:
                    pass
                ginfo = cl.getGroup(op.param1)
                contact = cl.getContact(op.param2).picturePath
                image = 'http://dl.profile.line.naver.jp'+contact
                welcomeMembers(op.param1, [op.param2])
                cl.sendImageWithURL(op.param1, image)
        if op.type == 19:
            if op.param1 in Proemail["proKick"]:
                if op.param2 in Leakiller or op.param2 in Proemail["Bots"] or op.param2 in Proemail["admin"]:
                    pass
                else:
                    try:
                        if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    ka.findAndAddContactsByMid(op.param3)
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kd.findAndAddContactsByMid(op.param3)
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(op.param3)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kf.findAndAddContactsByMid(op.param3)
                                                        kf.kickoutFromGroup(op.param1,[op.param2])
                                                        kf.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kg.findAndAddContactsByMid(op.param3)
                                                            kg.kickoutFromGroup(op.param1,[op.param2])
                                                            kg.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kh.findAndAddContactsByMid(op.param3)
                                                                kh.kickoutFromGroup(op.param1,[op.param2])
                                                                kh.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                try:
                                                                    ki.findAndAddContactsByMid(op.param3)
                                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                                except:
                                                                    try:
                                                                        kj.findAndAddContactsByMid(op.param3)
                                                                        kj.kickoutFromGroup(op.param1,[op.param2])
                                                                        kj.inviteIntoGroup(op.param1,[op.param3])
                                                                    except:
                                                                        try:
                                                                            random.choice(Amin).findAndAddContactsByMid(op.param3)
                                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                                        except:
                                                                            pass
                            else:pass
                        else:pass
                    except:
                        pass
        if op.type == 32:
            if op.param1 in Proemail["proCancel"]:
                if op.param2 in Leakiller or op.param2 in Proemail["Bots"] or op.param2 in Proemail["admin"]:
                    pass
                else:
                    try:
                        if op.param2 not in Leakiller and op.param2 not in Proemail["Bots"] and op.param2 not in Proemail["admin"]:
                            wait["blacklist"][op.param2] = True
                            if op.param3 not in wait["blacklist"]:
                                try:
                                    ka.findAndAddContactsByMid(op.param3)
                                    ka.kickoutFromGroup(op.param1,[op.param2])
                                    ka.inviteIntoGroup(op.param1,[op.param3])
                                except:
                                    try:
                                        kb.findAndAddContactsByMid(op.param3)
                                        kb.kickoutFromGroup(op.param1,[op.param2])
                                        kb.inviteIntoGroup(op.param1,[op.param3])
                                    except:
                                        try:
                                            kc.findAndAddContactsByMid(op.param3)
                                            kc.kickoutFromGroup(op.param1,[op.param2])
                                            kc.inviteIntoGroup(op.param1,[op.param3])
                                        except:
                                            try:
                                                kd.findAndAddContactsByMid(op.param3)
                                                kd.kickoutFromGroup(op.param1,[op.param2])
                                                kd.inviteIntoGroup(op.param1,[op.param3])
                                            except:
                                                try:
                                                    ke.findAndAddContactsByMid(op.param3)
                                                    ke.kickoutFromGroup(op.param1,[op.param2])
                                                    ke.inviteIntoGroup(op.param1,[op.param3])
                                                except:
                                                    try:
                                                        kf.findAndAddContactsByMid(op.param3)
                                                        kf.kickoutFromGroup(op.param1,[op.param2])
                                                        kf.inviteIntoGroup(op.param1,[op.param3])
                                                    except:
                                                        try:
                                                            kg.findAndAddContactsByMid(op.param3)
                                                            kg.kickoutFromGroup(op.param1,[op.param2])
                                                            kg.inviteIntoGroup(op.param1,[op.param3])
                                                        except:
                                                            try:
                                                                kh.findAndAddContactsByMid(op.param3)
                                                                kh.kickoutFromGroup(op.param1,[op.param2])
                                                                kh.inviteIntoGroup(op.param1,[op.param3])
                                                            except:
                                                                try:
                                                                    ki.findAndAddContactsByMid(op.param3)
                                                                    ki.kickoutFromGroup(op.param1,[op.param2])
                                                                    ki.inviteIntoGroup(op.param1,[op.param3])
                                                                except:
                                                                    try:
                                                                        kj.findAndAddContactsByMid(op.param3)
                                                                        kj.kickoutFromGroup(op.param1,[op.param2])
                                                                        kj.inviteIntoGroup(op.param1,[op.param3])
                                                                    except:
                                                                        try:
                                                                            random.choice(Amin).findAndAddContactsByMid(op.param3)
                                                                            random.choice(Amin).kickoutFromGroup(op.param1,[op.param2])
                                                                            random.choice(Amin).inviteIntoGroup(op.param1,[op.param3])
                                                                        except:
                                                                            pass
                            else:pass
                        else:pass
                    except:
                        pass
        if op.type == 55:
            try:
                if op.param1 in Proemail["readPoint"]:
                   if op.param2 in Proemail["readMember"][op.param1]:
                       pass
                   else:
                       Proemail["readMember"][op.param1][op.param2] = True
                else:
                   pass
            except:
                pass
        if op.type == 55:
            if cctv['cyduk'][op.param1]==True:
                if op.param1 in cctv['point']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in cctv['sidermem'][op.param1]:
                        pass
                    else:
                        cctv['sidermem'][op.param1] += "\n~ " + Name
                        siderMembers(op.param1, [op.param2])
        if op.type == 65:
            if Proemail["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict:
                        if msg_dict[msg_id]["from"]:
                           if msg_dict[msg_id]["text"] == 'Gambarnya dibawah':
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                zx = ""
                                zxc = ""
                                zx2 = []
                                xpesan =  "「 Gambar Dihapus 」\n• Pengirim : "
                                ret_ = "• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ry = str(ryan.displayName)
                                pesan = ''
                                pesan2 = pesan+"@x \n"
                                xlen = str(len(zxc)+len(xpesan))
                                xlen2 = str(len(zxc)+len(pesan2)+len(xpesan)-1)
                                zx = {'S':xlen, 'E':xlen2, 'M':ryan.mid}
                                zx2.append(zx)
                                zxc += pesan2
                                text = xpesan + zxc + ret_ + ""
                                cl.sendMessage(at, text, contentMetadata={'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}, contentType=0)
                                cl.sendImage(at, msg_dict[msg_id]["data"])
                           else:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict[msg_id]["from"])
                                ret_ =  "「 Pesan Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict[msg_id]["createdTime"])))
                                ret_ += "\n• Pesannya : {}".format(str(msg_dict[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                        del msg_dict[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 65:
            if Proemail["Unsend"] == True:
                try:
                    at = op.param1
                    msg_id = op.param2
                    if msg_id in msg_dict1:
                        if msg_dict1[msg_id]["from"]:
                                ginfo = cl.getGroup(at)
                                ryan = cl.getContact(msg_dict1[msg_id]["from"])
                                ret_ =  "「 Sticker Dihapus 」\n"
                                ret_ += "• Pengirim : {}".format(str(ryan.displayName))
                                ret_ += "\n• Nama Grup : {}".format(str(ginfo.name))
                                ret_ += "\n• Waktu Ngirim : {}".format(dt_to_str(cTime_to_datetime(msg_dict1[msg_id]["createdTime"])))
                                ret_ += "{}".format(str(msg_dict1[msg_id]["text"]))
                                cl.sendMessage(at, str(ret_))
                                cl.sendImage(at, msg_dict1[msg_id]["data"])
                        del msg_dict1[msg_id]
                except Exception as e:
                    print(e)
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != cl.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    msg_dict[msg.id] = {"text": msg.text, "from": msg._from, "createdTime": msg.createdTime, "contentType": msg.contentType, "contentMetadata": msg.contentMetadata}
                if msg.contentType == 1:
                    path = cl.downloadObjectMsg(msg_id)
                    msg_dict[msg.id] = {"text":'Gambarnya dibawah',"data":path,"from":msg._from,"createdTime":msg.createdTime}
                if msg.contentType == 7:
                   stk_id = msg.contentMetadata["STKID"]
                   stk_ver = msg.contentMetadata["STKVER"]
                   pkg_id = msg.contentMetadata["STKPKGID"]
                   ret_ = "\n\n「 Sticker Info 」"
                   ret_ += "\n• Sticker ID : {}".format(stk_id)
                   ret_ += "\n• Sticker Version : {}".format(stk_ver)
                   ret_ += "\n• Sticker Package : {}".format(pkg_id)
                   ret_ += "\n• Sticker Url : line://shop/detail/{}".format(pkg_id)
                   query = int(stk_id)
                   if type(query) == int:
                            data = 'https://stickershop.line-scdn.net/stickershop/v1/sticker/'+str(query)+'/ANDROID/sticker.png'
                            path = cl.downloadFileURL(data)
                            msg_dict1[msg.id] = {"text":str(ret_),"data":path,"from":msg._from,"createdTime":msg.createdTime}
        if op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 and msg.toType == 2:
                if sender != cl.profile.mid:
                    to = sender
                else:
                    to = receiver
            else:
                to = receiver
            if msg.contentType == 0:
                if text is None:
                    return
                if 'MENTION' in msg.contentMetadata.keys()!= None:
                    names = re.findall(r'@(\w+)', text)
                    mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                    mentionees = mention['MENTIONEES']
                    lists = []
                    for mention in mentionees:
                        if mid in mention['M']:
                            if Proemail["detectMention"] == True:
                                ca = cl.getContact(sender)
                                cl.sendMessage(to, "halo...☛❲ " + ca.displayName + "❳☚ ")
                                cl.sendMessage(to, Proemail["msgTag"])
                                cl.sendImageWithURL(to, "http://dl.profile.line-cdn.net/{}" .format(str(ca.pictureStatus)))
                            else:
                                pass
            if msg.contentType == 13:
              if Proemail["contact"] == True:
                 msg.contentType = 0
                 cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                 if 'displayName' in msg.contentMetadata:
                     contact = cl.getContact(msg.contentMetadata["mid"])
                     path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                     image = 'http://dl.profile.line.naver.jp'+path
                     cl.sendMessage(msg.to,"Nama : " + msg.contentMetadata["displayName"] + "\nMID : " + msg.contentMetadata["mid"] + "\nStatus Msg : " + contact.statusMessage + "\nPicture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus)
                     cl.sendImageWithURL(msg.to, image)
            if msg.contentType == 16:
                if Proemail["LikeOn"] == True:
                    url = msg.contentMetadata["postEndUrl"]
                    daftarLike = [1001,1002,1003,1004,1005,1006]
                    likeType = random.choice(daftarLike)
                    cl.likePost(url[25:58], url[66:], likeType)
                    cl.createComment(url[25:58], url[66:], Proemail["comment"])
            if msg.contentType == 16:
              if Proemail["checkPost"] == True:
                  try:
                      ret_ = "╔════[ Post Detail ]"
                      if msg.contentMetadata["serviceType"] == "GB":
                          contact = cl.getContact(sender)
                          auth = "\n╠☛ Author : {}".format(str(contact.displayName))
                      else:
                          auth = "\n╠☛ Author : {}".format(str(msg.contentMetadata["serviceName"]))
                      purl = "\n╠☛ Url : {}".format(str(msg.contentMetadata["postEndUrl"]).replace("line://","https://line.me/R/"))
                      ret_ += auth
                      ret_ += purl
                      if "mediaOid" in msg.contentMetadata:
                          object_ = msg.contentMetadata["mediaOid"].replace("svc=myhome|sid=h|","")
                          if msg.contentMetadata["mediaType"] == "V":
                              if msg.contentMetadata["serviceType"] == "GB":
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                                  murl = "\n╠☛ Url Media : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(msg.contentMetadata["mediaOid"]))
                              else:
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                                  murl = "\n╠☛ Url Media : https://obs-us.line-apps.com/myhome/h/download.nhn?{}".format(str(object_))
                              ret_ += murl
                          else:
                              if msg.contentMetadata["serviceType"] == "GB":
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(msg.contentMetadata["mediaOid"]))
                              else:
                                  ourl = "\n╠☛ Url Object : https://obs-us.line-apps.com/myhome/h/download.nhn?tid=612w&{}".format(str(object_))
                          ret_ += ourl
                      if "stickerId" in msg.contentMetadata:
                          stck = "\n╠☛ Sticker : https://line.me/R/shop/detail/{}".format(str(msg.contentMetadata["packageId"]))
                          ret_ += stck
                      if "text" in msg.contentMetadata:
                          text = "\n╠☛ Note : {}".format(str(msg.contentMetadata["text"]))
                          ret_ += text
                      ret_ += "\n╚══[ LIPRO SELF V.1 ]"
                      cl.sendMessage(to, str(ret_))
                  except:
                      cl.sendMessage(msg.to,"Invalid Post")
        if op.type == 25 or op.type == 26:
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            if msg.toType == 0 or msg.toType == 2:
               if msg.toType == 0:
                    to = receiver
               elif msg.toType == 2:
                    to = receiver
               if msg.contentType == 7:
                 if Proemail["sticker"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,"╔══════════════\n╠☛❲Check Sticker❳\n╠☛ STKID : " + msg.contentMetadata["STKID"] +"\n╠☛ STKPKGID : " + msg.contentMetadata["STKPKGID"] + "\n╠☛ STKVER : " + msg.contentMetadata["STKVER"] + "\n╠☛ " + "line://shop/detail/" + msg.contentMetadata["STKPKGID"] +"\n╚══════════════")
               if msg.contentType == 13:
                 if Proemail["contact"] == True:
                    msg.contentType = 0
                    cl.sendMessage(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        path = cl.getContact(msg.contentMetadata["mid"]).picturePath
                        image = 'http://dl.profile.line.naver.jp'+path
                        cl.sendMessage(msg.to,"╔══════════════\n╠☛ Nama : " + msg.contentMetadata["displayName"] + "\n╠☛ Mid : " + msg.contentMetadata["mid"] + "\n╠☛ Status : " + contact.statusMessage + "\n╠☛ Picture URL : http://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n╚══════════════")
                        cl.sendImageWithURL(msg.to, image)
               if msg.contentType == 13:
                 if msg._from in Zie:
                  if Proemail["abots"] == True:
                    if msg.contentMetadata["mid"] in Proemail["Bots"]:
                        cl.sendMessage(msg.to,"was bot friend")
                    else:
                        Proemail["Bots"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"succes add bots")
                 if Proemail["dbots"] == True:
                    if msg.contentMetadata["mid"] in Proemail["Bots"]:
                        del Proemail["Bots"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes remove bots")
                    else:
                        cl.sendMessage(msg.to,"Contact not in list bots")
                 if msg._from in Zie:
                  if Proemail["addadmin"] == True:
                    if msg.contentMetadata["mid"] in Proemail["admin"]:
                        cl.sendMessage(msg.to,"was admin")
                    else:
                        Proemail["admin"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"succes add admin")
                 if Proemail["deladmin"] == True:
                    if msg.contentMetadata["mid"] in Proemail["admin"]:
                        del Proemail["admin"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes remove admin")
                    else:
                        cl.sendMessage(msg.to,"Contact not in list admin")
                 if msg._from in Zie:
                  if Proemail["ablacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendMessage(msg.to,"was blacklist")
                    else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        cl.sendMessage(msg.to,"succes add in blacklist")
                 if Proemail["dblacklist"] == True:
                    if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendMessage(msg.to,"Succes remove blacklist")
                    else:
                        cl.sendMessage(msg.to,"Contact not in blacklist")
               if msg.toType == 2:
                 if msg._from in Zie:
                   if Proemail["gPicture"] == True:
                     path = cl.downloadObjectMsg(msg_id)
                     Proemail["gPicture"] = False
                     cl.updateGroupPicture(msg.to, path)
                     cl.sendMessage(msg.to, "Succes")
               if msg.contentType == 1:
                 if msg._from in Zie:
                   if Proemail["cPicture"] == True:
                     path1 = ka.downloadObjectMsg(msg_id)
                     path2 = kb.downloadObjectMsg(msg_id)
                     path3 = kc.downloadObjectMsg(msg_id)
                     path4 = kd.downloadObjectMsg(msg_id)
                     path5 = ke.downloadObjectMsg(msg_id)
                     path6 = kf.downloadObjectMsg(msg_id)
                     path7 = kg.downloadObjectMsg(msg_id)
                     path8 = kh.downloadObjectMsg(msg_id)
                     path9 = ki.downloadObjectMsg(msg_id)
                     path10 = kj.downloadObjectMsg(msg_id)
                     Proemail["cPicture"] = False
                     ka.updateProfilePicture(path1)
                     ka.sendMessage(msg.to, "Succes upload pic")
                     kb.updateProfilePicture(path2)
                     kb.sendMessage(msg.to, "Succes upload pic")
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to, "Succes upload pic")
                     kd.updateProfilePicture(path4)
                     kd.sendMessage(msg.to, "Succes upload pic")
                     ke.updateProfilePicture(path5)
                     ke.sendMessage(msg.to, "Succes upload pic")
                     kf.updateProfilePicture(path6)
                     kf.sendMessage(msg.to, "Succes upload pic")
                     kg.updateProfilePicture(path7)
                     kg.sendMessage(msg.to, "Succes upload pic")
                     kh.updateProfilePicture(path8)
                     kh.sendMessage(msg.to, "Succes upload pic")
                     ki.updateProfilePicture(path9)
                     ki.sendMessage(msg.to, "Succes upload pic")
                     kj.updateProfilePicture(path10)
                     kj.sendMessage(msg.to, "Succes upload pic")
               if msg.contentType == 1:
                 if msg._from in Zie:
                   if mid in Proemail["CLPicture"]:
                     path = cl.downloadObjectMsg(msg_id)
                     del Proemail["CLPicture"][mid]
                     cl.updateProfilePicture(path)
                     cl.sendMessage(msg.to,"succes update display picture")
                   if Amid in Proemail["cPicture"]:
                     path1 = ka.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Amid]
                     ka.updateProfilePicture(path1)
                     ka.sendMessage(msg.to,"succes update display picture")
                   if Bmid in Proemail["cPicture"]:
                     path2 = kb.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Bmid]
                     kb.updateProfilePicture(path2)
                     kb.sendMessage(msg.to,"succes update display picture")
                   if Cmid in Proemail["cPicture"]:
                     path3 = kc.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Cmid]
                     kc.updateProfilePicture(path3)
                     kc.sendMessage(msg.to,"succes update display picture")
                   if Dmid in Proemail["cPicture"]:
                     path4 = kd.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Dmid]
                     kd.updateProfilePicture(path4)
                     kd.sendMessage(msg.to,"succes update display picture")
                   if Emid in Proemail["cPicture"]:
                     path5 = ke.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Emid]
                     ke.updateProfilePicture(path5)
                     ke.sendMessage(msg.to,"succes update display picture")
                   if Fmid in Proemail["cPicture"]:
                     path6 = kf.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Fmid]
                     kf.updateProfilePicture(path6)
                     kf.sendMessage(msg.to,"succes update display picture")
                   if Gmid in Proemail["cPicture"]:
                     path7 = kg.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Gmid]
                     kg.updateProfilePicture(path7)
                     kg.sendMessage(msg.to,"succes update display picture")
                   if Hmid in Proemail["cPicture"]:
                     path8 = kb.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Hmid]
                     kh.updateProfilePicture(path8)
                     kh.sendMessage(msg.to,"succes update display picture")
                   if Imid in Proemail["cPicture"]:
                     path9 = ki.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Imid]
                     ki.updateProfilePicture(path9)
                     ki.sendMessage(msg.to,"succes update display picture")
                   if Jmid in Proemail["cPicture"]:
                     path10 = kj.downloadObjectMsg(msg_id)
                     del Proemail["cPicture"][Jmid]
                     kj.updateProfilePicture(path10)
                     kj.sendMessage(msg.to,"succes update display picture")
               if msg.contentType == 1:
                 if msg._from in Zie:
                   if Proemail["KPicture"] == True:
                     path11 = k1.downloadObjectMsg(msg_id)
                     path12 = k2.downloadObjectMsg(msg_id)
                     Proemail["KPicture"] = False
                     k1.updateProfilePicture(path11)
                     k1.sendMessage(msg.to, "succes update display picture")
                     k2.updateProfilePicture(path12)
                     k2.sendMessage(msg.to, "succes update display picture")
               if msg.contentType == 0:
                    if Proemail["autoRead"] == True:
                        cl.sendChatChecked(msg.to, msg_id)
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if cmd == "menu":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage = help()
                               cl.sendMessage(to, helpMessage)
                        if cmd == "menu1":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage1 = helpset()
                               cl.sendMessage(to, helpMessage1)
                        if cmd == "sbon":
                            if msg._from in Zie:
                                Proemail["selfbot"] = True
                                cl.sendMessage(msg.to, "Self bot mode on")
                        elif cmd == "sboff":
                            if msg._from in Zie:
                                Proemail["selfbot"] = False
                                cl.sendMessage(msg.to, "Self bot mode off")
                        elif cmd == "menu2":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               helpMessage2 = helpbot()
                               cl.sendMessage(to,helpMessage2)
                        elif cmd == "grupset":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                md = ""
                                if msg.to in Proemail["proqr"]: md+="􁤁􀇜╠☛ PʀᴏQr : ✓\n"
                                else: md+="􀔃􀆓╠☛ PʀᴏQr: ✘\n"
                                if msg.to in Proemail["proKick"]: md+="􁤁􀇜╠☛ Auto ᴋɪᴄᴋ : ✓\n"
                                else: md+="􀔃􀆓╠☛ Auto ᴋɪᴄᴋ : ✘\n"
                                if msg.to in Proemail["proCancel"]: md+="􁤁􀇜╠☛ Pʀᴏᴄᴀɴᴄᴇʟ : ✓\n"
                                else: md+="􀔃􀆓╠☛ PʀᴏᴄᴀɴᴄᴇL : ✘\n"
                                if msg.to in Proemail["proInvite"]: md+="􁤁􀇜╠☛ PʀᴏInvite : ✓\n"
                                else: md+="􀔃􀆓╠☛ PʀᴏInvite : ✘\n"
                                if msg.to in Proemail["intaPoint"]: md+="􁤁􀇜╠☛ IntaPoint : ✓\n"
                                else: md+="􀔃􀆓╠☛ IntaPoint : ✘\n"
                                if msg.to in Proemail["welcome"]: md+="􁤁􀇜╠☛ welcome : ✓\n"
                                else: md+="􀔃􀆓╠☛ Welcome : ✘\n"
                                if msg.to in Proemail["leaveMsg"]: md+="􁤁􀇜╠☛ Leave Msg : ✓\n"
                                else: md+="􀔃╠☛ Leave Msg : ✘\n"
                                cl.sendMessage(msg.to, "╔═══❲ Sett Group ❳════\n"+ md +"╚══════════════")
                        elif text.lower() == "status":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                md = ""
                                if Proemail["autoJoin"] == True: md+="􁤁􀇜╠☛ AᴜᴛᴏJᴏɪɴ : ✓\n"
                                else: md+="􀔃􀆓╠☛ AutoJoin : ✘\n"
                                if Proemail["autoJoinTicket"] == True: md+="􁤁􀇜╠☛ AᴜᴛᴏJᴏɪɴ Ticket: ✓\n"
                                else: md+="􀔃􀆓╠☛ AutoJoin Ticket: ✘\n"
                                if Proemail["sticker"] == True: md+="􁤁􀇜╠☛ Stickeʀ : ✓\n"
                                else: md+="􀔃􀆓╠☛ Stickeʀ ✘\n"
                                if Proemail["contact"] == True: md+="􁤁􀇜╠☛ Cᴏntacᴛ : ✓\n"
                                else: md+="􀔃􀆓╠☛ Cᴏntacᴛ : ✘ \n"
                                if Proemail["detectMention"] == True: md+="􁤁􀇜╠☛ Mention : ✓\n"
                                else: md+="􀔃􀆓╠☛ Mention : ✘\n"
                                if Proemail["autoAdd"] == True: md+="􁤁􀇜╠☛ Msg ᴀᴅᴅ : ✓\n"
                                else: md+="􀔃􀆓╠☛ Msg ᴀᴅᴅ : ✘\n"
                                cl.sendMessage(msg.to, "╔═══❲ Status Group ❳════\n"+ md +"╚══════════════")
                        elif cmd == "me" or text.lower() == 'me':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMentionFooter(to, '「My Name」\n', sender, "https://line.me/ti/p/j71.a", "http://dl.profile.line-cdn.net/"+cl.getContact(sender).pictureStatus, cl.getContact(sender).displayName);cl.sendMessage(to, cl.getContact(sender).displayName, contentMetadata = {'previewUrl': 'http://dl.profile.line-cdn.net/'+cl.getContact(sender).pictureStatus, 'i-installUrl': 'https://line.me/ti/p/ankrust86', 'type': 'mt', 'subText': "╔", 'a-installUrl': 'https://line.me/ti/p/~calon_almarhum99', 'a-installUrl': ' https://line.me/ti/p/ankrust86', 'a-packageName': 'com.spotify.music', 'countryCode': 'ID', 'a-linkUri': 'https://line.me/ti/p/ankrust86', 'i-linkUri': 'https://line.me/ti/p/ankrust86', 'id': 'mt000000000a6b79f9', 'text': '╔', 'linkUri': 'https://line.me/ti/p/ankrust86'}, contentType=19)
                        elif ("Gn " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                X = cl.getGroup(msg.to)
                                X.name = msg.text.replace("Gn ","")
                                cl.updateGroup(X)
                        elif ("Mid " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               if 'MENTION' in msg.contentMetadata.keys()!= None:
                                   names = re.findall(r'@(\w+)', text)
                                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   mentionees = mention['MENTIONEES']
                                   lists = []
                                   for mention in mentionees:
                                       if mention["M"] not in lists:
                                           lists.append(mention["M"])
                                   ret_ = ""
                                   for ls in lists:
                                       ret_ += "{}".format(str(ls))
                                   cl.sendMessage(to, str(ret_),{'AGENT_ICON': 'http://dl.profile.line-cdn.net/'+'M', 'AGENT_NAME': 'Mention', 'AGENT_LINK': 'http://line.me/ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath})
                        elif ("Info " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key1 = key["MENTIONEES"][0]["M"]
                               mi = cl.getContact(key1)
                               cl.sendMessage(msg.to, "☛ Nama : "+str(mi.displayName)+"\n☛ Mid : " +key1+"\n☛ Status Msg"+str(mi.statusMessage))
                               cl.sendMessage(msg.to, None, contentMetadata={'mid': key1}, contentType=13)
                               if "videoProfile='{" in str(cl.getContact(key1)):
                                   cl.sendVideoWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath)+'/vp.small')
                               else:
                                   cl.sendImageWithURL(msg.to, 'http://dl.profile.line.naver.jp'+str(mi.picturePath))
                        elif cmd == "mybot":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ka.sendContact(msg.to, Amid)
                               time.sleep(0.15)
                               kb.sendContact(msg.to, Bmid)
                               time.sleep(0.15)
                               kc.sendContact(msg.to, Cmid)
                               time.sleep(0.15)
                               kd.sendContact(msg.to, Dmid)
                               time.sleep(0.15)
                               ke.sendContact(msg.to, Emid)
                               time.sleep(0.15)
                               kf.sendContact(msg.to, Amid)
                               time.sleep(0.15)
                               kg.sendContact(msg.to, Bmid)
                               time.sleep(0.15)
                               kh.sendContact(msg.to, Cmid)
                               time.sleep(0.15)
                               ki.sendContact(msg.to, Dmid)
                               time.sleep(0.15)
                               kj.sendContact(msg.to, Emid)
                        elif text.lower() == "myrechat":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               try:
                                   cl.removeAllMessages(op.param2)
                               except:
                                   pass
                        elif cmd == "reject":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              ginvited = cl.getGroupIdsInvited()
                              if ginvited != [] and ginvited != None:
                                  for gid in ginvited:
                                      cl.rejectGroupInvitation(gid)
                                  cl.sendReplyMessage(msg_id, to, "Berhasil tolak sebanyak {} undZiean grup".format(str(len(ginvited))))
                              else:
                                  cl.sendReplyMessage(msg_id, to, "Tidak ada undZiean yZie tertunda")
                        elif cmd == "leave allgrup":
                          if msg._from in Zie:
                            group = cl.getGroupIdsJoined()
                            for i in group:
                                cl.sendMessage(i,"reinvite yg liat..bersih2 gc dulu!!")
                                cl.leaveGroup(i)
                                cl.sendMessage(msg.to,"succes leave all grup")
                        elif text.lower() == "rechat":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               try:
                                   ka.removeAllMessages(op.param2)
                                   ka.sendMessage(msg.to,"done ")
                                   kb.removeAllMessages(op.param2)
                                   kb.sendMessage(msg.to,"done ")
                                   kc.removeAllMessages(op.param2)
                                   kc.sendMessage(msg.to,"done ")
                                   kd.removeAllMessages(op.param2)
                                   kd.sendMessage(msg.to,"done ")
                                   ke.removeAllMessages(op.param2)
                                   ke.sendMessage(msg.to,"done ")
                                   kf.removeAllMessages(op.param2)
                                   kf.sendMessage(msg.to,"done ")
                                   kg.removeAllMessages(op.param2)
                                   kg.sendMessage(msg.to,"done ")
                                   kh.removeAllMessages(op.param2)
                                   kh.sendMessage(msg.to,"done ")
                                   ki.removeAllMessages(op.param2)
                                   ki.sendMessage(msg.to,"done ")
                                   kj.removeAllMessages(op.param2)
                                   kj.sendMessage(msg.to,"done ")
                               except:
                                   ka.removeAllMessages(op.param2)
                                   ka.sendMessage(msg.to,"done ")
                                   kb.removeAllMessages(op.param2)
                                   kb.sendMessage(msg.to,"done ")
                                   kc.removeAllMessages(op.param2)
                                   kc.sendMessage(msg.to,"done ")
                                   kd.removeAllMessages(op.param2)
                                   kd.sendMessage(msg.to,"done ")
                                   ke.removeAllMessages(op.param2)
                                   ke.sendMessage(msg.to,"done ")
                                   kf.removeAllMessages(op.param2)
                                   kf.sendMessage(msg.to,"done ")
                                   kg.removeAllMessages(op.param2)
                                   kg.sendMessage(msg.to,"done ")
                                   kh.removeAllMessages(op.param2)
                                   kh.sendMessage(msg.to,"done ")
                                   ki.removeAllMessages(op.param2)
                                   ki.sendMessage(msg.to,"done ")
                                   kj.removeAllMessages(op.param2)
                                   kj.sendMessage(msg.to,"done ")
                                   k1.removeAllMessages(op.param2)
                                   k1.sendMessage(msg.to,"done ")
                                   k2.removeAllMessages(op.param2)
                                   k2.sendMessage(msg.to,"done ")
                        elif cmd.startswith("bcg: "):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               sep = text.split(" ")
                               pesan = text.replace(sep[0] + " ","")
                               saya = cl.getGroupIdsJoined()
                               for group in saya:
                                   cl.sendMessage(group,"[ Broadcast ]\n" + str(pesan))
                        elif text.lower() == "mykey":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "key Now「 " + str(Proemail["keyCmd"]) + " 」")
                        elif cmd.startswith("setkey "):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               sep = text.split(" ")
                               key = text.replace(sep[0] + " ","")
                               if key in [""," ","\n",None]:
                                   cl.sendMessage(msg.to, "upload key failed")
                               else:
                                   Proemail["keyCmd"] = str(key).lower()
                                   cl.sendMessage(msg.to, "succes at「{}」".format(str(key).lower()))
                        elif text.lower() == "resetkey":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               Proemail["keyCmd"]=""
                               cl.sendMessage(msg.to, "succes resset key command")
                        elif cmd == "/reboot":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "waiting a second")
                               restartProgram()
                        elif cmd == "runtime":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               eltime = time.time()
                               bot = "was run " +waktu(eltime)
                               cl.sendMessage(to, bot)
                        elif cmd == "ginfo":
                          if msg._from in Zie:
                            try:
                                G = cl.getGroup(msg.to)
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                cl.sendMessage(msg.to, "  •⌻「Grup Info」⌻•\n\n Nama Group : {}".format(G.name)+ "\nID Group : {}".format(G.id)+ "\nPembuat : {}".format(G.creator.displayName)+ "\nWaktu Dibuat : {}".format(str(timeCreated))+ "\nJumlah Member : {}".format(str(len(G.members)))+ "\nJumlah Pending : {}".format(gPending)+ "\nGroup Qr : {}".format(gQr)+ "\nGroup Ticket : {}".format(gTicket))
                                cl.sendMessage(msg.to, None, contentMetadata={'mid': G.creator.mid}, contentType=13)
                                cl.sendImageWithURL(msg.to, 'http://dl.profile.line-cdn.net/'+G.pictureStatus)
                            except Exception as e:
                                cl.sendMessage(msg.to, str(e))
                        elif cmd.startswith("infogrup"):
                          if msg._from in Zie:
                            separate = text.split(" ")
                            number = text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                try:
                                    gCreator = G.creator.displayName
                                except:
                                    gCreator = "No file"
                                if G.invitee is None:
                                    gPending = "0"
                                else:
                                    gPending = str(len(G.invitee))
                                if G.preventedJoinByTicket == True:
                                    gQr = "Tertutup"
                                    gTicket = "Tidak ada"
                                else:
                                    gQr = "Terbuka"
                                    gTicket = "https://line.me/R/ti/g/{}".format(str(cl.reissueGroupTicket(G.id)))
                                timeCreated = []
                                timeCreated.append(time.strftime("%d-%m-%Y [ %H:%M:%S ]", time.localtime(int(G.createdTime) / 1000)))
                                ret_ += "  •⌻ List Grup Info ⌻•\n"
                                ret_ += "\n⌬ Nama Group : {}".format(G.name)
                                ret_ += "\n⌬ ID Group : {}".format(G.id)
                                ret_ += "\n⌬ Pembuat : {}".format(gCreator)
                                ret_ += "\n⌬ Waktu Dibuat : {}".format(str(timeCreated))
                                ret_ += "\n⌬ Jumlah Member : {}".format(str(len(G.members)))
                                ret_ += "\n⌬ Jumlah Pending : {}".format(gPending)
                                ret_ += "\n⌬ Group Qr : {}".format(gQr)
                                ret_ += "\n⌬ Group Ticket : {}".format(gTicket)
                                ret_ += ""
                                cl.sendMessage(to, str(ret_))
                            except:
                                pass
                        elif cmd.startswith("infomem"):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            ret_ = ""
                            try:
                                group = groups[int(number)-1]
                                G = cl.getGroup(group)
                                no = 0
                                ret_ = ""
                                for mem in G.members:
                                    no += 1
                                    ret_ += "\n " "● "+ str(no) + ". " + mem.displayName
                                cl.sendMessage(to,"● Group Name : [ " + str(G.name) + " ]\n\n   [ List Member ]\n" + ret_ + "\n\n「Total %i Members」" % len(G.members))
                            except:
                                pass
                        elif cmd.startswith("leave: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            number = msg.text.replace(separate[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            group = groups[int(number)-1]
                            for i in group:
                                ginfo = cl.getGroup(i)
                                if ginfo == group:
                                    ka.leaveGroup(i)
                                    kb.leaveGroup(i)
                                    kc.leaveGroup(i)
                                    kd.leaveGroup(i)
                                    ke.leaveGroup(i)
                                    ka.sendMessage(msg.to,"Succes leave in group " +str(ginfo.name))
                        elif cmd == "fiendlist":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = cl.getAllContactIds()
                               for i in gid:
                                   G = cl.getContact(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.displayName+ "\n"
                               cl.sendMessage(msg.to,"╔══[ FRIEND LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Friends ]")
                        elif cmd == "gruplist":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = cl.getGroupIdsJoined()
                               for i in gid:
                                   G = cl.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               cl.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "z1grup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = ka.getGroupIdsJoined()
                               for i in gid:
                                   G = ka.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               ka.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "z2grup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kb.getGroupIdsJoined()
                               for i in gid:
                                   G = kb.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kb.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "z3grup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kc.getGroupIdsJoined()
                               for i in gid:
                                   G = kc.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kc.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "z4grup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = kd.getGroupIdsJoined()
                               for i in gid:
                                   G = kd.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               kd.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "z5grup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = ke.getGroupIdsJoined()
                               for i in gid:
                                   G = ke.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               ke.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "kickergrup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               ma = ""
                               a = 0
                               gid = k1.getGroupIdsJoined()
                               for i in gid:
                                   G = k1.getGroup(i)
                                   a = a + 1
                                   end = "\n"
                                   ma += "╠ " + str(a) + ". " +G.name+ "\n"
                               k1.sendMessage(msg.to,"╔══[ GROUP LIST ]\n║\n"+ma+"║\n╚══[ Total「"+str(len(gid))+"」Groups ]")
                        elif cmd == "ourl":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = False
                                   cl.updateGroup(X)
                                gurl = cl.reissueGroupTicket(msg.to)
                                cl.sendMessage(msg.to,"line://ti/g/" + gurl)
                        elif cmd == "curl":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                   X = cl.getGroup(msg.to)
                                   X.preventedJoinByTicket = True
                                   cl.updateGroup(X)
                                   cl.sendMessage(msg.to, "done°")
#===========================================#
                        elif cmd == "pictgrup":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              if msg.toType == 2:
                                Proemail["gPicture"] = True
                                cl.sendMessage(msg.to,"please send pict")
                        elif cmd == "updp bot":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["cPicture"] = True
                                cl.sendMessage(msg.to,"please send pict")
                        elif 'Dpbot ' in msg.text:
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              spl = msg.text.replace('Dpbot ','')
                              if spl == '1':
                                  Proemail["cPicture"][Amid] = True
                                  ka.sendMessage(msg.to, "send pict boss")
                              if spl == '2':
                                  Proemail["cPicture"][Bmid] = True
                                  kb.sendMessage(msg.to, "send pict boss")
                              if spl == '3':
                                  Proemail["cPicture"][Cmid] = True
                                  kc.sendMessage(msg.to, "send pict boss")
                              if spl == '4':
                                  Proemail["cPicture"][Dmid] = True
                                  kd.sendMessage(msg.to, "send pict boss")
                              if spl == '5':
                                  Proemail["cPicture"][Emid] = True
                                  ke.sendMessage(msg.to, "send pict boss")
                              if spl == '6':
                                  Proemail["cPicture"][Fmid] = True
                                  kf.sendMessage(msg.to, "send pict boss")
                              if spl == '7':
                                  Proemail["cPicture"][Gmid] = True
                                  kg.sendMessage(msg.to, "send pict boss")
                              if spl == '8':
                                  Proemail["cPicture"][Hmid] = True
                                  kh.sendMessage(msg.to, "send pict boss")
                              if spl == '9':
                                  Proemail["cPicture"][Imid] = True
                                  ki.sendMessage(msg.to, "send pict boss")
                              if spl == '10':
                                  Proemail["cPicture"][Jmid] = True
                                  kj.sendMessage(msg.to, "send pict boss")
                        elif cmd == "my pict":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["CLPicture"][mid] = True
                                cl.sendMessage(msg.to,"please Send pict")
                        elif cmd == "kickerpict":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["KPicture"] = True
                                k1.sendMessage(msg.to,"please Send pict")
                                k2.sendMessage(msg.to,"please Send pict")
                        elif cmd.startswith("name: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = cl.getProfile()
                                profile.displayName = string
                                cl.updateProfile(profile)
                                cl.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z1cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ka.getProfile()
                                profile.displayName = string
                                ka.updateProfile(profile)
                                ka.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z2cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kb.getProfile()
                                profile.displayName = string
                                kb.updateProfile(profile)
                                kb.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z3cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kc.getProfile()
                                profile.displayName = string
                                kc.updateProfile(profile)
                                kc.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z4cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kd.getProfile()
                                profile.displayName = string
                                kd.updateProfile(profile)
                                kd.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z5cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ke.getProfile()
                                profile.displayName = string
                                ke.updateProfile(profile)
                                ke.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z6cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kf.getProfile()
                                profile.displayName = string
                                kf.updateProfile(profile)
                                kf.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z7cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kg.getProfile()
                                profile.displayName = string
                                kg.updateProfile(profile)
                                kg.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z8cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kh.getProfile()
                                profile.displayName = string
                                kh.updateProfile(profile)
                                kh.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z9cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = ki.getProfile()
                                profile.displayName = string
                                ki.updateProfile(profile)
                                ki.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("z10cn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = kj.getProfile()
                                profile.displayName = string
                                kj.updateProfile(profile)
                                kj.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd.startswith("kickercn: "):
                          if msg._from in Zie:
                            separate = msg.text.split(" ")
                            string = msg.text.replace(separate[0] + " ","")
                            if len(string) <= 10000000000:
                                profile = k1.getProfile()
                                profile = k2.getProfile()
                                profile.displayName = string
                                k1.updateProfile(profile)
                                k2.updateProfile(profile)
                                k1.sendMessage(msg.to,"Succes " + string + "")
                                k2.sendMessage(msg.to,"Succes " + string + "")
                        elif cmd == "tag" or text.lower() == 'mention':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                group = cl.getGroup(msg.to)
                                k = len(group.members)//20
                                for j in rZiee(k+1):
                                    aa = []
                                    for x in group.members[j*20 : (j+1)*20]:
                                        aa.append(x.mid)
                                    try:
                                        arrData = ""
                                        textx = "╔══════════════════\n╠☛ . "
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += "╠☛ . ".format(str(b))
                                            else:
                                                textx += "╚══════════════════\n╔══════════════════\n  「 ᴛᴏᴛᴀʟ ᴍᴇᴍʙᴇʀ : {} 」\n╚══════════════════".format(str(len(aa)))
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))

                                                except:
                                                    no = " "
                                        msg.to = msg.to
                                        msg.text = textx
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage(to, textx,{'AGENT_NAME':'[ Mentions ]', 'AGENT_LINK': 'line://ti/p/~{}'.format(cl.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + cl.getProfile().picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
                                    except Exception as e:
                                        cl.sendText(msg.to,str(e))
                        elif ("Add con " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                   targets.append(x["M"])
                               for target in targets:
                                   try:
                                       kays = cl.getContact(target)
                                       cl.findAndAddContactsByMid(kays.mid)
                                       cl.sendMessage(msg.to,"Done add " + cl.getContact(target).displayName + " Done add my friend")
                                   except Exception as e:
                                       print(e)
                        elif cmd == "botlist":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                a = 0
                                for m_id in Proemail["Bots"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| Friend Botz •\n\n"+ma+"Total : 「%s」 Bot" %(str(len(Proemail["Bots"]))))
                        elif cmd == "adminlist":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                mb = ""
                                b = 0
                                for m_id in Proemail["admin"]:
                                    b = b + 1
                                    end = '\n'
                                    mb += str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| ADMIN •\n\n"+mb+"\nTotal :「%s」 Admin Bot" %(str(len(Proemail["admin"]))))
                        elif cmd == ".bots":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                ka.sendMessage(msg.to,"Yes daddy")
                                kb.sendMessage(msg.to,"Yes daddy")
                                kc.sendMessage(msg.to,"Yes daddy")
                                kd.sendMessage(msg.to,"Yes daddy")
                                ke.sendMessage(msg.to,"Yes daddy")
                                kf.sendMessage(msg.to,"Yes daddy")
                                kg.sendMessage(msg.to,"Yes daddy")
                                kh.sendMessage(msg.to,"Yes daddy")
                                ki.sendMessage(msg.to,"Yes daddy")
                                kj.sendMessage(msg.to,"Yes daddy")
                        elif cmd == ".inv":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                try:
                                    Zie = [Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid]
                                    cl.inviteIntoGroup(msg.to, Zie)
                                    ka.acceptGroupInvitation(msg.to)
                                    kb.acceptGroupInvitation(msg.to)
                                    kc.acceptGroupInvitation(msg.to)
                                    kd.acceptGroupInvitation(msg.to)
                                    ke.acceptGroupInvitation(msg.to)
                                    kf.acceptGroupInvitation(msg.to)
                                    kg.acceptGroupInvitation(msg.to)
                                    kh.acceptGroupInvitation(msg.to)
                                    ki.acceptGroupInvitation(msg.to)
                                    kj.acceptGroupInvitation(msg.to)
                                except:
                                    pass
                        elif cmd == "js stay":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Zie = [Smid,Kmid]
                                try:
                                    cl.inviteIntoGroup(msg.to, Zie)
                                except:
                                    try:
                                        random.choice(Amin).inviteIntoGroup(msg.to, Zie)
                                    except:
                                        pass
                        elif cmd == "jscancel":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Zie = [Smid,Kmid]
                                try:
                                    cl.cancelGroupInvitation(msg.to, Zie)
                                except:
                                    try:
                                        random.choice(Amin).cancelGroupInvitation(msg.to, Zie)
                                    except:
                                        pass
                        elif cmd == "js bye":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                k1.sendMessage(msg.to, "see u member "+str(G.name))
                                k2.sendMessage(msg.to, "see u member "+str(G.name))
                                k1.leaveGroup(msg.to)
                                k2.leaveGroup(msg.to)
                        elif cmd == ".come":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kd.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kf.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kg.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kh.acceptGroupInvitationByTicket(msg.to,Ticket)
                                ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                                kj.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                cl.updateGroup(G)
                                random.choice(Amin).inviteIntoGroup(msg.to,[Smid,Kmid])
                        elif cmd == ".out":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              try:
                                  G = cl.getGroup(msg.to)
                                  ka.sendMessage(msg.to, "see you 😎 "+str(G.name))
                                  kb.leaveGroup(msg.to)
                                  kc.leaveGroup(msg.to)
                                  kd.leaveGroup(msg.to)
                                  ke.leaveGroup(msg.to)
                                  kf.leaveGroup(msg.to)
                                  kg.leaveGroup(msg.to)
                                  kh.leaveGroup(msg.to)
                                  ki.leaveGroup(msg.to)
                                  kj.leaveGroup(msg.to)
                                  ka.leaveGroup(msg.to)
                              except:
                                  pass
                        elif cmd == "/pro":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to, "see u member "+str(G.name))
                                cl.leaveGroup(msg.to)
                        elif cmd == "projs join":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                G = cl.getGroup(msg.to)
                                G.preventedJoinByTicket = False
                                cl.updateGroup(G)
                                invsend = 0
                                Ticket = cl.reissueGroupTicket(msg.to)
                                k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                                k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                                G = k1.getGroup(msg.to)
                                G.preventedJoinByTicket = True
                                k1.updateGroup(G)
                        elif cmd == ".speed respon":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                get_profile_time_start = time.time()
                                get_profile = cl.getProfile()
                                get_profile_time = time.time() - get_profile_time_start
                                get_group_time_start = time.time()
                                get_group = cl.getGroupIdsJoined()
                                get_group_time = time.time() - get_group_time_start
                                get_contact_time_start = time.time()
                                get_contact = cl.getContact(mid)
                                get_contact_time = time.time() - get_contact_time_start
                                cl.sendMessage(msg.to, "🚩response 🚩\n\n - 🌏 Speed Profile\n   %.10f\n - ➡ Speed Contact\n   %.10f\n - ➡ Speed Group\n   %.10f" % (get_profile_time/3,get_contact_time/3,get_group_time/3))
                        elif cmd == "speed" or cmd == "sp":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               start = time.time()
                               cl.sendMessage(to, "•••")
                               elapsed_time = time.time() - start
                               cl.sendMessage(to,format(str(elapsed_time)))
                        elif cmd == ".speed" or cmd == ".sp":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               start = time.time()
                               ka.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start
                               ka.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start2 = time.time()
                               kb.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start2
                               kb.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start3 = time.time()
                               kc.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start3
                               kc.sendMessage(msg.to, "%s " % (elapsed_time))
                               start4 = time.time()
                               kd.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start4
                               kd.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start5 = time.time()
                               ke.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start5
                               ke.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start6 = time.time()
                               kf.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start6
                               kf.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start7 = time.time()
                               kg.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start7
                               kg.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start8 = time.time()
                               kh.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start8
                               kh.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start9 = time.time()
                               ki.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start9
                               ki.sendMessage(msg.to, "%s s" % (elapsed_time))
                               start10 = time.time()
                               kj.sendMessage("u3b07c57b6239e5216aa4c7a02687c86d", '.')
                               elapsed_time = time.time() - start10
                               kj.sendMessage(msg.to, "%s s" % (elapsed_time))
                        elif cmd == "lurk on":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 Proemail['readPoint'][msg.to] = msg_id
                                 Proemail['readMember'][msg.to] = {}
                                 cl.sendMessage(msg.to, "Lurking berhasil diaktifkan\nTZiegal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                        elif cmd == "lurk off":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                 tz = pytz.timezone("Asia/Jakarta")
                                 timeNow = datetime.now(tz=tz)
                                 del Proemail['readPoint'][msg.to]
                                 del Proemail['readMember'][msg.to]
                                 cl.sendMessage(msg.to, "Lurking berhasil dinoaktifkan\nTZiegal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nJam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]")
                        elif cmd == "lurkers":
                          if msg._from in Zie:
                            if msg.to in Proemail['readPoint']:
                                if Proemail['readMember'][msg.to] != {}:
                                    aa = []
                                    for x in Proemail['readMember'][msg.to]:
                                        aa.append(x)
                                    try:
                                        arrData = ""
                                        textx = "  [ Result {} member ]    \n  [ Lurkers ]\n1. ".format(str(len(aa)))
                                        arr = []
                                        no = 1
                                        b = 1
                                        for i in aa:
                                            b = b + 1
                                            end = "\n"
                                            mention = "@x\n"
                                            slen = str(len(textx))
                                            elen = str(len(textx) + len(mention) - 1)
                                            arrData = {'S':slen, 'E':elen, 'M':i}
                                            arr.append(arrData)
                                            tz = pytz.timezone("Asia/Jakarta")
                                            timeNow = datetime.now(tz=tz)
                                            textx += mention
                                            if no < len(aa):
                                                no += 1
                                                textx += str(b) + ". "
                                            else:
                                                try:
                                                    no = "[ {} ]".format(str(cl.getGroup(msg.to).name))
                                                except:
                                                    no = "  "
                                        msg.to = msg.to
                                        msg.text = textx+"\n⌬ TZiegal : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n⌚ Jam [ "+ datetime.strftime(timeNow,'%H:%M:%S')+" ]"
                                        msg.contentMetadata = {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}
                                        msg.contentType = 0
                                        cl.sendMessage1(msg)
                                    except:
                                        pass
                                    try:
                                        del Proemail['readPoint'][msg.to]
                                        del Proemail['readMember'][msg.to]
                                    except:
                                        pass
                                    Proemail['readPoint'][msg.to] = msg.id
                                    Proemail['readMember'][msg.to] = {}
                                else:
                                    cl.sendMessage(msg.to, "User kosong...")
                            else:
                                cl.sendMessage(msg.to, "Ketik lurking on ")
                        elif cmd == "sider on":
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              try:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cl.sendMessage(msg.to, "╔══════════════\n╠☛ starting cek sider\n╚══════════════\n╔══════════════\n╠☛ date : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\n╠☛ hour "+ datetime.strftime(timeNow,'%H:%M:%S')+"\n╚══════════════")
                                  del cctv['point'][msg.to]
                                  del cctv['sidermem'][msg.to]
                                  del cctv['cyduk'][msg.to]
                              except:
                                  pass
                              cctv['point'][msg.to] = msg.id
                              cctv['sidermem'][msg.to] = ""
                              cctv['cyduk'][msg.to]=True
                        elif cmd == "sider off":
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              if msg.to in cctv['point']:
                                  tz = pytz.timezone("Asia/Jakarta")
                                  timeNow = datetime.now(tz=tz)
                                  cctv['cyduk'][msg.to]=False
                                  cl.sendMessage(msg.to, "╔══════════════\n╠☛ sider off mode\n╚══════════════")
                              else:
                                  cl.sendMessage(msg.to, "sider in off mode")
                        elif cmd.startswith("cekdate: "):
                          if msg._from in Zie:
                            sep = msg.text.split(" ")
                            tZiegal = msg.text.replace(sep[0] + " ","")
                            r=requests.get('https://script.google.com/macros/exec?service=AKfycbw7gKzP-WYV2F5mc9RaR7yE3Ve1yN91Tjs91hp_jHSE02dSv9w&nama=ervan&tZiegal='+tZiegal)
                            data=r.text
                            data=json.loads(data)
                            lahir = data["data"]["lahir"]
                            usia = data["data"]["usia"]
                            ultah = data["data"]["ultah"]
                            zodiak = data["data"]["zodiak"]
                            cl.sendMessage(msg.to,"⇸「 I N F O 」⇷\n\n"+" Date Of Birth : "+lahir+"\n Age : "+usia+"\n Ultah : "+ultah+"\n Zodiak : "+zodiak)
                        elif cmd.startswith("max: "):
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Proemail["Maxlimit"] = num
                                cl.sendMessage(msg.to,"Max spam Tag " +strnum)
                        elif cmd.startswith("scall: "):
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                                proses = text.split(":")
                                strnum = text.replace(proses[0] + ":","")
                                num =  int(strnum)
                                Proemail["limit"] = num
                                cl.sendMessage(msg.to,"Max spam call " +strnum)
                        elif cmd.startswith("stag "):
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                                if 'MENTION' in msg.contentMetadata.keys()!=None:
                                    key = eval(msg.contentMetadata["MENTION"])
                                    key1 = key["MENTIONEES"][0]["M"]
                                    zx = ""
                                    zxc = " "
                                    zx2 = []
                                    pesan2 = "@a"" "
                                    xlen = str(len(zxc))
                                    xlen2 = str(len(zxc)+len(pesan2)-1)
                                    zx = {'S':xlen, 'E':xlen2, 'M':key1}
                                    zx2.append(zx)
                                    zxc += pesan2
                                    msg.contentType = 0
                                    msg.text = zxc
                                    lol = {'MENTION':str('{"MENTIONEES":'+json.dumps(zx2).replace(' ','')+'}')}
                                    msg.contentMetadata = lol
                                    jmlh = int(Proemail["Maxlimit"])
                                    if jmlh <= 1000:
                                        for x in rZiee(jmlh):
                                            try:
                                                cl.sendMessage1(msg)
                                            except Exception as e:
                                                cl.sendMessage(msg.to,str(e))
                                    else:
                                        cl.sendMessage(msg.to,"Jumlah melebihi 1000")
                        elif cmd == "scall":
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                             if msg.toType == 2:
                                group = cl.getGroup(to)
                                members = [mem.mid for mem in group.members]
                                jmlh = int(Proemail["limit"])
                                cl.sendMessage(to, "Succes {} Spam Call".format(str(Proemail["limit"])))
                                if jmlh <= 1000:
                                  for x in rZiee(jmlh):
                                     try:
                                         cl.acquireGroupCallRoute(to)
                                         cl.inviteIntoGroupCall(to, contactIds=members)
                                     except:
                                         pass
                                else:
                                    cl.sendMessage(to,"Jumlah melebihi batas")
                        elif 'Gift: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              korban = msg.text.replace('Gift: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in rZiee(0,jumlah):
                                      cl.sendMessage(midd, None, contentMetadata={'PRDID': 'a0768339-c2d3-4189-9653-2909e9bb6f58', 'PRDTYPE': 'THEME', 'MSGTPL': '6'}, contentType=9)
                        elif 'Spam: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              korban = msg.text.replace('Spam: ','')
                              korban2 = korban.split()
                              midd = korban2[0]
                              jumlah = int(korban2[1])
                              if jumlah <= 1000:
                                  for var in rZiee(0,jumlah):
                                      cl.sendMessage(midd, str(Proemail["spamMsg"]))
                                      ka.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kb.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kc.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kd.sendMessage(midd, str(Proemail["spamMsg"]))
                                      ke.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kf.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kg.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kh.sendMessage(midd, str(Proemail["spamMsg"]))
                                      ki.sendMessage(midd, str(Proemail["spamMsg"]))
                                      kj.sendMessage(midd, str(Proemail["spamMsg"]))
                        elif 'ID line: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              msgs = msg.text.replace('ID line: ','')
                              conn = cl.findContactsByUserid(msgs)
                              if True:
                                  cl.sendMessage(msg.to, "http://line.me/ti/p/~" + msgs)
                                  cl.sendMessage(msg.to, None, contentMetadata={'mid': conn.mid}, contentType=13)
                        elif 'Welcome ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Welcome ','')
                              if spl == 'on':
                                  if msg.to in Proemail["welcome"]:
                                       msgs = "Msg Welcome was on"
                                  else:
                                       Proemail["welcome"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "In Group: " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["welcome"]:
                                         del Proemail["welcome"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "In Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Msg Welcome mode on"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif 'Left ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Left ','')
                              if spl == 'on':
                                  if msg.to in Proemail["leaveMsg"]:
                                       msgs = "Msg Left was on"
                                  else:
                                       Proemail["leaveMsg"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "In Group: " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["leaveMsg"]:
                                         del Proemail["leaveMsg"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "In Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Msg Leave mode on"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif 'Proqr ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Proqr ','')
                              if spl == 'on':
                                  if msg.to in Proemail["proqr"]:
                                       msgs = "Succes"
                                  else:
                                       Proemail["proqr"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "In Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["proqr"]:
                                         del Proemail["proqr"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "In Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Protect url on"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif 'Autokick ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Autokick ','')
                              if spl == 'on':
                                  if msg.to in Proemail["proKick"]:
                                       msgs = "Autokick on"
                                  else:
                                       Proemail["proKick"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "In Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["proKick"]:
                                         del Proemail["proKick"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "In Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Autokick off"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif 'Procancel ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Procancel ','')
                              if spl == 'on':
                                  if msg.to in Proemail["proCancel"]:
                                       msgs = "Procancel on"
                                  else:
                                       Proemail["proCancel"] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "In Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["proCancel"]:
                                         Proemail["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "In Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Procancel off"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif 'Protect ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Protect ','')
                              if spl == 'on':
                                  if msg.to in Proemail["proqr"]:
                                       msgs = ""
                                  else:
                                       Proemail["proqr"][msg.to] = True
                                  if msg.to in Proemail["proKick"]:
                                      msgs = ""
                                  else:
                                       Proemail["proKick"][msg.to] = True
                                  if msg.to in Proemail["proInvite"]:
                                      msgs = ""
                                  else:
                                       Proemail["proInvite"][msg.to] = True
                                  if msg.to in Proemail["proCancel"]:
                                      ginfo = cl.getGroup(msg.to)
                                      msgs = "High Allprotection mode on at : " +str(ginfo.name)
                                  else:
                                       Proemail["proCancel"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "High Allprotection mode on at : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["proqr"]:
                                         del Proemail["proqr"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Proemail["proKick"]:
                                         del Proemail["proKick"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Proemail["proInvite"]:
                                         del Proemail["proInvite"][msg.to]
                                    else:
                                         msgs = ""
                                    if msg.to in Proemail["proCancel"]:
                                         del Proemail["proCancel"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protection mode off at : " +str(ginfo.name)
                                    else:
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Protection mode off at : " +str(ginfo.name)
                                    cl.sendMessage(msg.to, "「off mode」\n\n" + msgs)
                        elif 'Js ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              spl = msg.text.replace('Inta ','')
                              if spl == 'on':
                                  if msg.to in Proemail["intaPoint"]:
                                       msgs = "Inta on"
                                  else:
                                       Proemail["intaPoint"][msg.to] = True
                                       ginfo = cl.getGroup(msg.to)
                                       msgs = "IntaPoint on at Group : " +str(ginfo.name)
                                  cl.sendMessage(msg.to, "「on mode」\n" + msgs)
                              elif spl == 'off':
                                    if msg.to in Proemail["intaPoint"]:
                                         del Proemail["intaPoint"][msg.to]
                                         ginfo = cl.getGroup(msg.to)
                                         msgs = "Intapoint off at Group : " +str(ginfo.name)
                                    else:
                                         msgs = "Inta off"
                                    cl.sendMessage(msg.to, "「off mode」\n" + msgs)
                        elif (".kick " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Zie and target not in Bots:
                                       try:
                                           wait["blacklist"][target] = True
                                           random.choice(Amin).kickoutFromGroup(msg.to, [target])
                                       except:
                                           random.choice(Amin).sendMessage(msg.to,"limit bosquh")
                        elif (".Kiss " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Zie and target not in Bots:
                                       try:
                                           cl.kickoutFromGroup(msg.to, [target])
                                       except:
                                           cl.sendMessage(msg.to,"limit bosquh")
                        elif (".Jskick " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               _name = msg.text.replace("Gkick ","")
                               _nametarget = _name.rstrip('  ')
                               gs = cl.getGroup(msg.to)
                               targets = []
                               gs.preventedJoinByTicket = False
                               cl.updateGroup(gs)
                               Invsend = 0
                               Ti = cl.reissueGroupTicket(msg.to)
                               k1.acceptGroupInvitationByTicket(msg.to,Ti)
                               k2.acceptGroupInvitationByTicket(msg.to,Ti)
                               if 'MENTION' in msg.contentMetadata.keys() != None:
                                   names = re.findall(r'@(\w+)', msg.text)
                                   mention = ast.literal_eval(msg.contentMetadata['MENTION'])
                                   mentionees = mention['MENTIONEES']
                                   for mention in mentionees:
                                       try:
                                           cok=[k1,k2]
                                           sup=random.choice(cok)
                                           sup.kickoutFromGroup(msg.to, [mention['M']])
                                           time.sleep(0.001)
                                       except:
                                           pass
                               gs = k1.getGroup(msg.to)
                               gs.preventedJoinByTicket = True
                               k1.updateGroup(gs)
                               k1.leaveGroup(msg.to)
                               k2.leaveGroup(msg.to)
                        elif (".Cancel" in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "empty ")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in Zie and x not in Bots and x not in Proemail["Bots"] and x not in Proemail["admin"]:
                                       cl.cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.3)
                                   cl.sendMessage(to, "done.")
                        elif (".Bot cancel" in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               group = cl.getGroup(msg.to)
                               if group.invitee is None:
                                   cl.sendMessage(op.message.to, "empty ")
                               else:
                                   nama = [contact.mid for contact in group.invitee]
                                   for x in nama:
                                     if x not in Zie and x not in Bots and x not in Proemail["Bots"] and x not in Proemail["admin"]:
                                       random.choice(Amin).cancelGroupInvitation(msg.to, [x])
                                       time.sleep(0.3)
                                   cl.sendMessage(to, "done.")
                        elif (".admin " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Proemail["admin"]:
                                       cl.sendMessage(msg.to,"was admin")
                                   else:
                                       try:
                                           Proemail["admin"][target] = True
                                           cl.sendMessage(msg.to,"Succes add admin")
                                       except:
                                           pass
                        elif ("Addbot " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in Proemail["Bots"]:
                                       cl.sendMessage(msg.to,"was bot")
                                   else:
                                       try:
                                           Proemail["Bots"][target] = True
                                           cl.sendMessage(msg.to,"Succes add bot")
                                       except:
                                           pass
                        elif (".Deladmin " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Proemail["admin"]:
                                       cl.sendMessage(msg.to,"not in admin")
                                   else:
                                        try:
                                            del Proemail["admin"][target]
                                            cl.sendMessage(msg.to,"Succes delete admin")
                                        except:
                                            pass
                        elif ("Delbot " in msg.text):
                          if Znfwait["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in Proemail["Bots"]:
                                       cl.sendMessage(msg.to,"not in bots")
                                   else:
                                        try:
                                            del Proemail["Bots"][target]
                                            cl.sendMessage(msg.to,"Succes delete bots")
                                        except:
                                            pass
                        elif cmd == "cbot" or text.lower() == 'clear bot':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              Zie = cl.getContacts(Proemail["Bots"])
                              mc = "%i Bots " % len(Zie)
                              cl.sendMessage(msg.to,"done boss " +mc)
                              Proemail["Bots"] = {}
                        elif cmd == "cadmin" or text.lower() == 'clear admin':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              Zie = cl.getContacts(Proemail["admin"])
                              mc = "%i Admin " % len(Zie)
                              cl.sendMessage(msg.to,"done boss " +mc)
                              Proemail["admin"] = {}
                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["addadmin"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "admin:del" or text.lower() == 'admin:del':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["deladmin"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "admin:off" or text.lower() == 'admin off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["addadmin"] = False
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "deladmin:off" or text.lower() == 'deladmin off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["deladmin"] = False
                                cl.sendMessage(msg.to,"done")
                        elif cmd == "bot:on" or text.lower() == 'bot on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["abots"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "bot:off" or text.lower() == 'bot off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["abots"] = False
                                cl.sendMessage(msg.to,"done boss")
                        elif cmd == "bot:del" or text.lower() == 'bot del':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["dbots"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "delbot:off" or text.lower() == 'delbot off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["dbots"] = False
                                cl.sendMessage(msg.to,"done")
                        elif cmd == "allrefresh" or text.lower() == 'refresh':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["addadmin"] = False
                                Proemail["deladmin"] = False
                                Proemail["abots"] = False
                                Proemail["dbots"] = False
                                Proemail["ablacklist"] = False
                                Proemail["dblacklist"] = False
                                cl.sendMessage(msg.to,"done bosquh")
                        elif cmd == "killban":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                if msg.toType == 2:
                                    group = cl.getGroup(msg.to)
                                    gMembMids = [contact.mid for contact in group.members]
                                    matched_list = []
                                    for tag in wait["blacklist"]:
                                        matched_list+=filter(lambda str: str == tag, gMembMids)
                                    if matched_list == []:
                                        return
                                    for jj in matched_list:
                                        try:
                                            random.choice(Amin).kickoutFromGroup(msg.to,[jj])
                                            print (msg.to,[jj])
                                        except:
                                            pass
                        elif cmd == "ctbot" or text.lower() == 'ctbot':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                for i in Proemail["Bots"]:
                                    ma = cl.getContact(i)
                                    cl.sendMessage(msg.to, None, contentMetadata={'mid': i}, contentType=13)
                        elif cmd == "contact:on" or text.lower() == 'contact on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["contact"] = True
                                cl.sendMessage(msg.to,"Contact allready on")
                        elif cmd == "contact:off" or text.lower() == 'contact off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["contact"] = False
                                cl.sendMessage(msg.to,"Contact allready off")
                        elif cmd == "respon:on" or text.lower() == 'respon on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["detectMention"] = True
                                cl.sendMessage(msg.to,"Auto allready on")
                        elif cmd == "respon:off" or text.lower() == 'respon off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["detectMention"] = False
                                cl.sendMessage(msg.to,"Auto respon allready off")
                        elif cmd == "autojoin:on" or text.lower() == 'autojoin on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoJoin"] = True
                                cl.sendMessage(msg.to,"Autojoin allredy on")
                        elif cmd == "autojoin:off" or text.lower() == 'autojoin off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoJoin"] = False
                                cl.sendMessage(msg.to,"Autojoin allready off")
                        elif cmd == "like:on" or text.lower() == 'like on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              Proemail["LikeOn"] = True
                              cl.sendMessage(msg.to,"Auto Like allready on")
                        elif cmd == "like:off" or text.lower() == 'like off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              Proemail["LikeOn"] = False
                              cl.sendMessage(msg.to,"Auto Like allready off")
                        elif cmd == "scan:on" or text.lower() == 'scan on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["checkmid"] = True
                                cl.sendMessage(msg.to," allredy on")
                        elif cmd == "scan:off" or text.lower() == 'scan off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["checkmid"] = False
                                cl.sendMessage(msg.to," allready off")
                        elif cmd == "post:on" or text.lower() == 'post on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["checkPost"] = True
                                cl.sendMessage(msg.to,"Check Post allredy on")
                        elif cmd == "post:off" or text.lower() == 'post off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["checkPost"] = False
                                cl.sendMessage(msg.to,"Check Post allready off")
                        elif cmd == "unsend:on" or text.lower() == 'unsend on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["Unsend"] = True
                                cl.sendMessage(msg.to,"Detect unsend allredy on")
                        elif cmd == "unsend:off" or text.lower() == 'unsend off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["Unsend"] = False
                                cl.sendMessage(msg.to,"Detect unsend allready off")
                        elif cmd == "autoadd:on" or text.lower() == 'autoadd on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoAdd"] = True
                                cl.sendMessage(msg.to,"Auto add allready on")
                        elif cmd == "autoadd:off" or text.lower() == 'autoadd off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoAdd"] = False
                                cl.sendMessage(msg.to,"Auto add allready off")
                        elif cmd == "sticker:on" or text.lower() == 'sticker on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["sticker"] = True
                                cl.sendMessage(msg.to,"Sticker allready on")
                        elif cmd == "sticker:off" or text.lower() == 'sticker off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["sticker"] = False
                                cl.sendMessage(msg.to,"Sticker alleady off")
                        elif cmd == "jticket:on" or text.lower() == 'jticket on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoJoinTicket"] = True
                                cl.sendMessage(msg.to,"Join ticket allready on")
                        elif cmd == "jticket:off" or text.lower() == 'jticket off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["autoJoinTicket"] = False
                                cl.sendMessage(msg.to,"Notag allready off")
                        elif ("Ban " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"was blacklist")
                                   else:
                                       try:
                                           wait["blacklist"][target] = True
                                           cl.sendMessage(msg.to,"Succes add blacklist")
                                       except:
                                           pass
                        elif (".cban " in msg.text):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               key = eval(msg.contentMetadata["MENTION"])
                               key["MENTIONEES"][0]["M"]
                               targets = []
                               for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                               for target in targets:
                                   if target not in wait["blacklist"]:
                                       cl.sendMessage(msg.to,"not in blacklist")
                                   else:
                                       try:
                                           del wait["blacklist"][target]
                                           cl.sendMessage(msg.to,"Succes removed blacklist")
                                       except:
                                           pass
                        elif cmd == "ban:on" or text.lower() == 'ban on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["ablacklist"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "ban:off" or text.lower() == 'ban off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["ablacklist"] = False
                                cl.sendMessage(msg.to,"done boss")
                        elif cmd == "unban:on" or text.lower() == 'unban on':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["dblacklist"] = True
                                cl.sendMessage(msg.to,"Send Contact...")
                        elif cmd == "unban:off" or text.lower() == 'unban off':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                Proemail["dblacklist"] = False
                                cl.sendMessage(msg.to,"done boss")
                        elif cmd == "banlist" or text.lower() == 'banlist':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                                ma = ""
                                a = 0
                                for m_id in wait["blacklist"]:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"| Blacklist ●\n\n"+ma+"\nTotal : 「%s」 Blacklist User " %(str(len(wait["blacklist"]))))
                        elif cmd == "cban" or text.lower() == 'cban':
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              ang = cl.getContacts(wait["blacklist"])
                              mc = "%i Blacklist " % len(ang)
                              cl.sendMessage(msg.to,"done boss " +mc)
                              wait["blacklist"] = {}
                        elif 'Add: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Add: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["message"] = Zie
                                  cl.sendMessage(msg.to, "「Msg add」 :\n\n「{}」".format(str(Zie)))
                        elif 'Left: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Left: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["leftmsg"] = Zie
                                  cl.sendMessage(msg.to, "「Msg leave」 :\n\n「{}」".format(str(Zie)))
                        elif 'Welcome: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Welcome: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["sambutan"] = Zie
                                  cl.sendMessage(msg.to, "「Msg wellcome」 :\n\n「{}」".format(str(Zie)))
                        elif 'Tag: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Tag: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["msgTag"] = Zie
                                  cl.sendMessage(msg.to, "「Msg tag」:\n\n「{}」".format(str(Zie)))
                        elif 'Spam: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              ang = msg.text.replace('Spam: ','')
                              if ang in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["spamMsg"] = Zie
                                  cl.sendMessage(msg.to, "「Msg spam」 :\n\n「{}」".format(str(Zie)))
                        elif 'Sider: ' in msg.text:
                          if Proemail["selfbot"] == True:
                           if msg._from in Zie:
                              znf = msg.text.replace('Sider: ','')
                              if znf in [""," ","\n",None]:
                                  cl.sendMessage(msg.to, "Gagal boss")
                              else:
                                  Proemail["siderMsg"] = znf
                                  cl.sendMessage(msg.to, "「Msg cctv」:\n\n「{}」".format(str(znf)))
                        elif text.lower() == "cekmsg":
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               cl.sendMessage(msg.to, "「Msg add」 :\n「 " + str(Proemail["message"]) + " 」")
                               cl.sendMessage(msg.to, "「Msg cctv」:\n「 " + str(Proemail["siderMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「Msg tag」:\n「 " + str(Proemail["msgTag"]) + " 」")
                               cl.sendMessage(msg.to, "「Msg spam」:\n「 " + str(Proemail["spamMsg"]) + " 」")
                               cl.sendMessage(msg.to, "「Msg welcome」:\n「 " + str(Proemail["sambutan"]) + " 」")
                               cl.sendMessage(msg.to, "「Msg leave」:\n「 " + str(Proemail["leftmsg"]) + " 」")
#===========JOIN TICKET============#
                        elif "/ti/g/" in msg.text.lower():
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                              if Proemail["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "succes join : %s" % str(group.name))
                        elif (msg.text in "Cleanse"):
                          if Proemail["selfbot"] == True:
                            if msg._from in Zie:
                               if msg.toType == 2:
                                  group = cl.getGroup(msg.to)
                                  nama = [contact.mid for contact in group.members]
                                  for x in nama:
                                      if x not in Leakiller:
                                          if x not in Proemail["Bots"]:
                                              if x not in Proemail["admin"]:
                                                  try:
                                                      random.choice(Amin).kickoutFromGroup(msg.to,[x])
                                                  except:
                                                      print ("limit")
                        elif msg.text.lower() in ["check"]:
                            if msg._from in Zie:
                                anu = cl.getGroup(msg.to)
                                oncom = ["uafee8af1c47101fa12ae93e28da1ec80"] #MID PUSKUN
                                for _mid in oncom:
                                    message="╭━™LeaBot-Version™━─\n"
                                    try:
                                        cl.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「☹ Limit」Kick\n"
                                    try:
                                        ka.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kb.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「☹ Limit」Kick\n"
                                    try:
                                        kc.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kd.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「☹ Limit」Kick\n"
                                    try:
                                        ke.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kf.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kg.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kh.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「☹ Limit」Kick\n"
                                    try:
                                        ki.inviteIntoGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Invite\n"
                                    except:
                                        message+="│「☹ Limit」Invite\n"
                                    try:
                                        kj.kickoutFromGroup(msg.to,[_mid])
                                        message+="│「☇Fresh」Kick\n"
                                    except:
                                        message+="│「☹ Limit」Kick\n"
                                    message+="╰━━━━━━━━─"
                                    cl.sendMessage(msg.to,message)
#=====================#
    except Exception as error:
        print (error)

while True:
    try:
        ops = linePoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
                linePoll.setRevision(op.revision)
                thread = threading.Thread(target=bot, args=(op,))
                thread.start()
    except Exception as e:
        print(e)
